package com.example.availablitysvc.app.availablitymodule.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "store_custom_bom_mapping")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class StoreCustomBomMapping {

    @Id
    @Column(name = "location_code", nullable = false, length = 50)
    private String locationCode;

    @Column(name = "fssai_no", length = 50)
    private String fssaiNo;

    @Column(name = "custom_bom_group_code", length = 50)
    private String customBomGroupCode;

}
