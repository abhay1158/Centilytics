package com.example.availablitysvc.app.eventloggingmodule.controller;

import com.example.availablitysvc.app.eventloggingmodule.dto.EventLoggingDto;
import com.example.availablitysvc.app.eventloggingmodule.dto.Filter;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingFilterRequest;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingFilterRequestWithDate;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingModel;
import com.example.availablitysvc.app.eventloggingmodule.model.WrapperResponse;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RequestMapping("/api/events")
public interface EventLoggingController {


    @PostMapping
    public ResponseEntity<WrapperResponse> eventLogging(@RequestBody EventLoggingModel eventLoggingModel,
                                                        @RequestHeader(value = "X-Tenant-ID") String tenantId);


    @PostMapping(path = "/live-data", consumes = "application/json", produces = "application/json")
    public Page<EventLoggingDto> getEventLoggingDataWithFilters(
            @RequestBody EventLoggingFilterRequest req,
            @RequestHeader("X-Tenant-ID") String tenantId);

    @PostMapping(path = "/historic-data", consumes = "application/json", produces = "application/json")
    public Page<EventLoggingDto> getHistoricData(
            @RequestBody EventLoggingFilterRequestWithDate eventLoggingFilterRequest,
            @RequestHeader("X-Tenant-ID") String tenantId);

    @GetMapping("/filter")
    public Filter.FiltersResponse getFilters();

}
