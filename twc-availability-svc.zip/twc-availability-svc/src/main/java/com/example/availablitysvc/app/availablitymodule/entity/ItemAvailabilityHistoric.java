package com.example.availablitysvc.app.availablitymodule.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "item_availability_historic")
public class ItemAvailabilityHistoric {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "iah_seq")
    @SequenceGenerator(
            name = "iah_seq",
            sequenceName = "item_availability_historic_id_seq",
            allocationSize = 1
    )
    @Column(name = "id")
    private Long id;

    @Column(name = "item_id", nullable = false, updatable = false)
    private String itemId;

    @Column(name = "item_description")
    private String itemDescription;

    @Column(name = "unit_of_measure")
    private String unitOfMeasure;

    @Column(name = "quantity")
    private BigDecimal quantity;

    @Column(name = "category_code")
    private String categoryCode;

    @Column(name = "inventory_posting_group")
    private String inventoryPostingGroup;

    @Column(name = "availability")
    private BigDecimal availability;

    @Column(name = "last_updated_date_and_time")
    private LocalDateTime lastUpdatedDateAndTime;
}
