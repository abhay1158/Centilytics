package com.example.availablitysvc.app.eventloggingmodule.enums;


public enum Status {
    Success,
    Failed


//    SUCCESS("Success"),
//    FAILED("Failed");
//
//    private final String displayName;
//
//    Status(String displayName) {
//        this.displayName = displayName;
//    }
//
//    public String getDisplayName() {
//        return displayName;
//    }
}
