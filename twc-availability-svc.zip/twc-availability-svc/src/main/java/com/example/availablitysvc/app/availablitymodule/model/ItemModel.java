package com.example.availablitysvc.app.availablitymodule.model;


import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class ItemModel {
    private String itemId;
    private String itemDescription;
    private String unitOfMeasure;
    private BigDecimal quantity;
    private String categoryCode;
//    String inventoryPostingGroup;
    private BigDecimal availability;
    private LocalDateTime lastUpdatedDateAndTime;
}
