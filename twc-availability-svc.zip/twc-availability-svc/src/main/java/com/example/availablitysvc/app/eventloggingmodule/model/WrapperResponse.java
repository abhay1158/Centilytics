package com.example.availablitysvc.app.eventloggingmodule.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WrapperResponse {

    private String response;
    private String errorMessage;
    private String message;
}