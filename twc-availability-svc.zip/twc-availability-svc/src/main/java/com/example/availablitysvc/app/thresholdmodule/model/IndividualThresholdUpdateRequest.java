package com.example.availablitysvc.app.thresholdmodule.model;

import lombok.Data;

@Data
public class IndividualThresholdUpdateRequest {
    private String itemId;
    private Integer minimumThresholdValue;
}
