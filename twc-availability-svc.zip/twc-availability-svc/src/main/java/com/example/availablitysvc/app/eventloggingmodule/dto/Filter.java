package com.example.availablitysvc.app.eventloggingmodule.dto;

public class Filter {
    public record FilterOption(String id, String value, String label) {}

    // The response wrapper
    public record FiltersResponse(
            java.util.List<FilterOption> status,
            java.util.List<FilterOption> eventType
    ) {}
}
