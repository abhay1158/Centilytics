package com.example.availablitysvc.app.thresholdmodule.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "thresholds")
@Data
public class ThresholdEntity {

    @Id
    private String id;

    private String description;

    @Column(name = "base_unit_of_measure")
    private String baseUnitOfMeasure;

    @Column(name = "inventory_posting_group")
    private String inventoryPostingGroup;

    @Column(name = "item_category_code")
    private String itemCategoryCode;

    @Column(name = "item_category_id")
    private String itemCategoryId;

    @Column(name = "minimum_threshold_value")
    private Integer minimumThresholdValue;

}
