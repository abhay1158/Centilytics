package com.example.availablitysvc.app.eventloggingmodule.service;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class StableIds {
    private StableIds() {}

    // Deterministic UUID based on a namespace + value (same input => same UUID)
    public static String uuidFor(String namespace, String value) {
        String key = namespace + ":" + value;
        UUID uuid = UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8));
        return uuid.toString();
    }

    // Pretty label: "Purchase_GRN" -> "Purchase GRN"
    public static String toLabel(String enumName) {
        String spaced = enumName.replace('_', ' ');
        String[] parts = spaced.split("\\s+");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].isEmpty()) continue;
            b.append(Character.toUpperCase(parts[i].charAt(0)))
                    .append(parts[i].substring(1).toLowerCase());
            if (i < parts.length - 1) b.append(' ');
        }
        return b.toString();
    }
}
