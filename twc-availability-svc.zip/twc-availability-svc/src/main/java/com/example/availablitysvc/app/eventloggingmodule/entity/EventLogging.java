package com.example.availablitysvc.app.eventloggingmodule.entity;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "event_logging")
public class EventLogging extends AuditableEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "event_log_seq")
    @SequenceGenerator(
            name = "event_log_seq",
            sequenceName = "event_log_sequence",
            allocationSize = 1,
            initialValue = 100000
    )
    @Column(name = "event_id")
    private Long eventId;

    @Column(name = "event_type")
    @Enumerated(EnumType.STRING)
    private EventType eventType;

    @Column(name = "item_code")
    private String itemCode;

    @Column(name = "item_description")
    private String itemDescription;

    @Column(name = "unit_of_measure")
    private String unitOfMeasure;

    @Column(name = "quantity")
    private BigDecimal quantity;

    @Column(name = "reason")
    private String reason;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "event_logged_time")
    private LocalDateTime eventLoggedTime;

    @Column(name = "event_nature")
    @Enumerated(EnumType.STRING)
    private EventNature eventNature;

    @Column(name = "inventory_posting_group")
    String inventoryPostingGroup;
}
