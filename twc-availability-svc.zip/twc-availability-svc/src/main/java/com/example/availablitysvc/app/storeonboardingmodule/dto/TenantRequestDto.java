package com.example.availablitysvc.app.storeonboardingmodule.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class TenantRequestDto {

    @Schema(description = "Unique tenant identifier", example = "S067")
    private String tenantId;

}