package com.example.availablitysvc.app.thresholdmodule.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ThresholdModel {
    private String id;
    private String description;
    private String baseUnitOfMeasure;
    private String inventoryPostingGroup;
    private String itemCategoryCode;
    private Integer minimumThresholdValue;
}
