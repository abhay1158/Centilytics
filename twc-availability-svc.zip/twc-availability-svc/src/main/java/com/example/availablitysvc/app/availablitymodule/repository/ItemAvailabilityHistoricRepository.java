package com.example.availablitysvc.app.availablitymodule.repository;

import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailability;
import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailabilityHistoric;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ItemAvailabilityHistoricRepository extends JpaRepository<ItemAvailabilityHistoric, Long> {
    @Query(
            value = """
    SELECT DISTINCT ON (i.item_id) i.*
    FROM item_availability i
    WHERE i.inventory_posting_group = :inventoryPostingGroup
      AND i.last_updated_date_and_time <= :availabilityDateAndTime
    ORDER BY i.item_id ASC, i.last_updated_date_and_time DESC
    """,
            countQuery = """
    SELECT COUNT(DISTINCT i.item_id)
    FROM item_availability i
    WHERE i.inventory_posting_group = :inventoryPostingGroup
      AND i.last_updated_date_and_time <= :availabilityDateAndTime
    """,
            nativeQuery = true
    )
    Page<ItemAvailability> findAllByInventoryPostingGroupByDate(
            @Param("inventoryPostingGroup") String inventoryPostingGroup,
            @Param("availabilityDateAndTime") LocalDateTime availabilityDateAndTime,
            Pageable pageable
    );

    @Query("""
                SELECT i FROM ItemAvailability i
                WHERE (:#{#inventoryGroups == null || #inventoryGroups.isEmpty()} = true OR i.inventoryPostingGroup IN :inventoryGroups)
                  AND (:#{#categoryCodes == null || #categoryCodes.isEmpty()} = true OR i.categoryCode IN :categoryCodes)
                  AND (:availabilityDateAndTime IS NULL OR i.lastUpdatedDateAndTime <= :availabilityDateAndTime)
                ORDER BY i.lastUpdatedDateAndTime DESC
                """)
    Page<ItemAvailability> filterByMultipleInventoryGroupsAndCategoryCodesByDate(
            @Param("inventoryGroups") List<String> inventoryGroups,
            @Param("categoryCodes") List<String> categoryCodes,
            @Param("availabilityDateAndTime") LocalDateTime availabilityDateAndTime,
            Pageable pageable
    );

    @Query(value = """
    SELECT DISTINCT ON (i.item_id) *
    FROM item_availability_historic i
    WHERE i.item_id IN (:itemCodes)
      AND i.last_updated_date_and_time <= :availabilityDateAndTime
    ORDER BY i.item_id, i.last_updated_date_and_time DESC
    """,
            nativeQuery = true)
    List<ItemAvailability> findByItemIdInByDate(
            @Param("itemCodes") List<String> itemCodes,
            @Param("availabilityDateAndTime") LocalDateTime availabilityDateAndTime
    );
}
