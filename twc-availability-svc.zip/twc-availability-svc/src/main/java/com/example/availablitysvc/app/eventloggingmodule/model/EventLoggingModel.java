package com.example.availablitysvc.app.eventloggingmodule.model;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.aspectj.lang.annotation.RequiredTypes;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventLoggingModel {
    @NotNull(message = "eventType is required")
    private EventType eventType;

    @NotEmpty(message = "items must not be empty")
    private List <ItemDetail> items;

    @NotNull(message = "eventLoggedTime is required")
    private LocalDateTime eventLoggedTime;

    private String reason;
    @NotNull
    private EventNature eventNature;
}
