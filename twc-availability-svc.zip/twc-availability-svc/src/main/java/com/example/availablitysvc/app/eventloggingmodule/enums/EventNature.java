package com.example.availablitysvc.app.eventloggingmodule.enums;

public enum EventNature {
    IN,
    OUT
}
