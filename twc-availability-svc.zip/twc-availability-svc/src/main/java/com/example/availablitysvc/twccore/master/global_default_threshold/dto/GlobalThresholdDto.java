package com.example.availablitysvc.twccore.master.global_default_threshold.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GlobalThresholdDto {
    private String itemCategoryCode;
    private Integer thresholdValue;
}
