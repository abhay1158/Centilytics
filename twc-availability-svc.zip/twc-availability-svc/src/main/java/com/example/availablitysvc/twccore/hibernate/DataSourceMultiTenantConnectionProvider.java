package com.example.availablitysvc.twccore.hibernate;

import com.example.availablitysvc.twccore.tenant.TenantDataSourceProvider;
import com.zaxxer.hikari.HikariDataSource;
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@Component
public class DataSourceMultiTenantConnectionProvider implements MultiTenantConnectionProvider<Object> {

    private final TenantDataSourceProvider provider;
    private final DataSource defaultDataSource;

    public DataSourceMultiTenantConnectionProvider(TenantDataSourceProvider provider, DataSource defaultDataSource) {
        this.provider = provider;
        this.defaultDataSource = defaultDataSource;
    }

    @Override
    public Connection getAnyConnection() throws SQLException {
        return defaultDataSource.getConnection();
    }

    @Override
    public void releaseAnyConnection(Connection connection) throws SQLException {
        connection.close();
    }

    @Override
    public Connection getConnection(Object tenantIdentifier) throws SQLException {
        String tenantId = (tenantIdentifier == null) ? "default" : String.valueOf(tenantIdentifier);
        HikariDataSource ds = provider.getDataSource(tenantId);
        return ds.getConnection();
    }

    @Override
    public void releaseConnection(Object tenantIdentifier, Connection connection) throws SQLException {
        connection.close();
    }

    @Override
    public boolean supportsAggressiveRelease() {
        return false;
    }

    @Override
    public boolean isUnwrappableAs(Class unwrapType) {
        return false;
    }

    @Override
    public <T> T unwrap(Class<T> unwrapType) {
        return null;
    }
}
