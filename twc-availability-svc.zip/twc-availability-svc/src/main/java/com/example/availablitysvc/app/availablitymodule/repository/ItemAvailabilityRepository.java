package com.example.availablitysvc.app.availablitymodule.repository;

import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailability;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ItemAvailabilityRepository extends JpaRepository<ItemAvailability, String> {

        @Query("SELECT i FROM ItemAvailability i " +
                "WHERE LOWER(i.itemId) LIKE LOWER(CONCAT('%', :query, '%')) " +
                "   OR LOWER(i.itemDescription) LIKE LOWER(CONCAT('%', :query, '%'))")
        Page<ItemAvailability> searchByItemIdOrDescription(@Param("query") String query, Pageable pageable);

        @Query("SELECT i FROM ItemAvailability i " +
                "WHERE (:inventoryGroups IS NULL OR i.inventoryPostingGroup IN :inventoryGroups) " +
                "AND (:categoryCodes IS NULL OR i.categoryCode IN :categoryCodes)")
        Page<ItemAvailability> filterByMultipleInventoryGroupsAndCategoryCodes(
                @Param("inventoryGroups") List<String> inventoryGroups,
                @Param("categoryCodes") List<String> categoryCodes,
                Pageable pageable
        );
        @Query("SELECT DISTINCT i.inventoryPostingGroup FROM ItemAvailability i WHERE i.inventoryPostingGroup IS NOT NULL")
        List<String> findDistinctInventoryPostingGroups();


        Page<ItemAvailability> findAllByInventoryPostingGroup(String inventoryPostingGroup, Pageable pageable);

        ItemAvailability findItemAvailabilityByItemId(String itemId);

        @Query("select i.quantity from ItemAvailability i where i.itemId = :itemId")
        BigDecimal findItemQuantityByItemId(@Param("itemId") String itemId);

        List<ItemAvailability> findByItemIdIn(List<String> itemIds);


        @Modifying
        @Transactional
        @Query("""
        UPDATE ItemAvailability i
        SET i.availability = :availability,
            i.quantity = :quantity,
            i.lastUpdatedDateAndTime = :lastUpdatedDateAndTime
        WHERE i.itemId = :itemId
    """)
        int updateAvailabilityAndQuantityByItemCode(
                @Param("itemCode") String itemId,
                @Param("availability") BigDecimal availability,
                @Param("quantity") BigDecimal quantity,
                @Param("lastUpdatedDateAndTime") LocalDateTime lastUpdatedDateAndTime
        );

        @Modifying
        @Transactional
        @Query("""
        UPDATE ItemAvailability i
        SET i.availability = :availability,
            i.lastUpdatedDateAndTime = :lastUpdatedDateAndTime
        WHERE i.itemId = :itemId
    """)
        int updateAvailabilityByItemCode(
                @Param("itemCode") String itemId,
                @Param("availability") BigDecimal availability,
                @Param("lastUpdatedDateAndTime") LocalDateTime lastUpdatedDateAndTime
        );

}
