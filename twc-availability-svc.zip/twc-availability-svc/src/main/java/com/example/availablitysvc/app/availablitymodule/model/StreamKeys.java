package com.example.availablitysvc.app.availablitymodule.model;

public final class StreamKeys {
    private StreamKeys() {}
    public static final String STREAM = "inventory:stream";
    public static final String GROUP  = "invgrp";
}