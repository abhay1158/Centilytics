package com.example.availablitysvc.twccore.master.locationmodule.service;

import com.example.availablitysvc.twccore.master.locationmodule.model.LocationModel;
import com.example.availablitysvc.twccore.master.locationmodule.repository.LocationRepository;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class LocationService {

    @Autowired
    private LocationRepository locationRepository;

    public List<LocationModel> getAllLocations() {
        return locationRepository.findAll();
    }

    public List<LocationModel> searchLocations(String query) {
        return locationRepository
                .findByCodeContainingIgnoreCaseOrNameContainingIgnoreCaseOrAddressContainingIgnoreCaseOrCityContainingIgnoreCase(
                        query, query, query, query
                );
    }

    @Transactional
    public String updateMultipleLocationStatuses(Map<String, Boolean> locationStatusMap) {
        StringBuilder responseBuilder = new StringBuilder();
        locationStatusMap.forEach((code, enable) -> {
            Optional<LocationModel> optionalLocation = locationRepository.findById(code);
            if (optionalLocation.isPresent()) {
                LocationModel location = optionalLocation.get();
                location.setEnableLocation(enable);
                locationRepository.save(location);
                responseBuilder.append("Updated: ").append(code)
                        .append(" -> enable_location = ").append(enable).append("\n");
            } else {
                responseBuilder.append("Not Found: ").append(code).append("\n");
            }
        });

        return responseBuilder.toString();
    }

}
