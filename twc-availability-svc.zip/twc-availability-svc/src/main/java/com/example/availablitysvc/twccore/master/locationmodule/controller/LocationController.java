package com.example.availablitysvc.twccore.master.locationmodule.controller;

import com.example.availablitysvc.twccore.master.locationmodule.model.LocationModel;
import com.example.availablitysvc.twccore.master.locationmodule.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/locations")
public class LocationController {

    @Autowired
    private LocationService locationService;

    @GetMapping
    public List<LocationModel> getAllLocations() {
        return locationService.getAllLocations();
    }

    @GetMapping("/search")
    public List<LocationModel> searchLocations(@RequestParam("query") String query) {
        return locationService.searchLocations(query);
    }
    @PostMapping("/toggle")
    public ResponseEntity<String> toggleLocations(@RequestBody Map<String, Boolean> locationStatusMap) {
        String result = locationService.updateMultipleLocationStatuses(locationStatusMap);
        return ResponseEntity.ok(result);
    }


}
