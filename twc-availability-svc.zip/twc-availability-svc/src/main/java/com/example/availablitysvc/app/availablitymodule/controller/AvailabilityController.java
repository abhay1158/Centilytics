package com.example.availablitysvc.app.availablitymodule.controller;

import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailability;

import com.example.availablitysvc.app.availablitymodule.model.AvailabilityAssemblyBOM;
import com.example.availablitysvc.app.availablitymodule.model.ItemAvailabilityFilterRequest;


import com.example.availablitysvc.app.availablitymodule.service.AvailabilityService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/availability")
public class AvailabilityController {
    @Autowired
    private AvailabilityService availabilityService;

    @GetMapping
    public Page<ItemAvailability> getFgAvailabilityByDefault(
            @RequestHeader(name = "X-Tenant-ID") String tenantId,
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(name = "availabilityDate", required = false) LocalDateTime availabilityDateAndTime
    ) {
        return availabilityService.getAllFgItemAvailability(tenantId, pageable,availabilityDateAndTime);
    }

    @GetMapping("/search")
    public Page<ItemAvailability> searchItems(
            @RequestParam("query") String query,
            @PageableDefault(size = 20) Pageable pageable,
            @RequestHeader(name = "X-Tenant-ID") String tenantId
    ) {
        return availabilityService.searchLocations(query, pageable,tenantId);
    }
    @PostMapping("/filter")
    public Page<ItemAvailability> filterItems(
            @RequestBody ItemAvailabilityFilterRequest filterRequest,
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(name = "availabilityDate", required = false) LocalDateTime availabilityDateAndTime,
            @RequestHeader(name = "X-Tenant-ID") String tenantId
    ) {
        return availabilityService.filterItems(
                filterRequest.getInventoryGroups(),
                filterRequest.getCategoryCodes(),
                pageable,
                availabilityDateAndTime,
                tenantId
        );
    }
    @GetMapping("/inventory-groups")
    public List<String> getInventoryGroups(@RequestHeader(name = "X-Tenant-ID") String tenantId) {
        return availabilityService.getDistinctInventoryPostingGroups(tenantId);
    }

    @GetMapping("/assembly-bom")
    public AvailabilityAssemblyBOM getAssemblyBom(
            @RequestHeader(name = "X-Tenant-ID") String tenantId,
            @RequestParam("itemId") String itemId,
            @RequestParam(name = "availabilityDate", required = false) LocalDateTime availabilityDateAndTime
    ) {
        if(availabilityService.assemblyBomData(itemId).isPresentCustomBOM()==false){

            return availabilityService.getEnrichedAssemblyBomWithAvailability(tenantId,itemId,availabilityDateAndTime);
        }
        else if(availabilityService.assemblyBomData(itemId).isPresentCustomBOM()==true &&
                availabilityService.getStoreCustomBomMapping(tenantId)==null
        ){
            return availabilityService.getEnrichedAssemblyBomWithAvailability(tenantId,itemId,availabilityDateAndTime);
        }
        else{
            return availabilityService.getEnrichedCustomBomWithAvailability(tenantId,itemId,availabilityDateAndTime);
        }

    }

}
