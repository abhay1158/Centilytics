package com.example.availablitysvc.app.storeonboardingmodule.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "tenant_db_config")
@Data
public class TenantDbConfig {

//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment ID
//    private Long id; // Matches BIGINT autoIncrement

    @Id
    @Column(name = "tenant_id")
    private String tenantName; // Matches tenant_name

    @Column(name = "jdbc_url")
    private String dbUrl;      // Matches db_url

    @Column(name = "username")
    private String dbUsername; // Matches db_username

    @Column(name = "password")
    private String dbPassword; // Matches db_password

    public String getTenantName() {
        return tenantName;
    }

    public String getDbUrl() {
        return dbUrl;
    }

    public String getDbUsername() {
        return dbUsername;
    }

    public String getDbPassword() {
        return dbPassword;
    }
}