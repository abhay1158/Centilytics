package com.example.availablitysvc.twccore.master.global_default_threshold.service;

import com.example.availablitysvc.twccore.master.global_default_threshold.dto.GlobalThresholdDto;
import com.example.availablitysvc.twccore.master.global_default_threshold.entity.DefaultThreshold;
import com.example.availablitysvc.twccore.master.global_default_threshold.repository.GlobalThresholdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GlobalThresholdService {
    @Autowired
    private GlobalThresholdRepository globalThresholdRepository;
    public List<GlobalThresholdDto> getGlobalThreshold() {
        return globalThresholdRepository.findAll()
                .stream()
                .map(e -> {
                    GlobalThresholdDto dto = new GlobalThresholdDto();
                    dto.setItemCategoryCode(e.getItemCategoryCode());
                    dto.setThresholdValue(e.getThresholdValue()); // may be null; that’s fine
                    return dto;
                })
                .toList();
    }

    public Optional<DefaultThreshold> getGlobalThresholdByItem(String itemCategoryCode){
        return globalThresholdRepository.findByItemCategoryCode((itemCategoryCode));
    }
}
