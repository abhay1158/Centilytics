package com.example.availablitysvc.twccore.master.global_default_threshold.repository;

import com.example.availablitysvc.app.thresholdmodule.entity.ThresholdEntity;
import com.example.availablitysvc.twccore.master.global_default_threshold.entity.DefaultThreshold;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GlobalThresholdRepository extends JpaRepository<DefaultThreshold, String> {

    @Query("SELECT t FROM DefaultThreshold t WHERE t.itemCategoryCode = :itemCategoryCode ORDER BY t.id ASC LIMIT 1")
    Optional<DefaultThreshold> findFirstByItemCategoryCode(@Param("itemCategoryCode") String itemCategoryCode);

    Optional<DefaultThreshold> findByItemCategoryCode(String itemCategoryCode);
}
