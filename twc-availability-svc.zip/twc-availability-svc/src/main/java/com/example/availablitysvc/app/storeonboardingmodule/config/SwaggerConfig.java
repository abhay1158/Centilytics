package com.example.availablitysvc.app.storeonboardingmodule.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "Store Onboarding and Deboarding API",
                version = "1.0",
                description = "API for managing tenant onboarding and deboarding in the availability service"
        )
)
public class SwaggerConfig {
}