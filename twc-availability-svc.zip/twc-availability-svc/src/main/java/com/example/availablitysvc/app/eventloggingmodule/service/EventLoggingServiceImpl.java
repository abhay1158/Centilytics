package com.example.availablitysvc.app.eventloggingmodule.service;


import com.example.availablitysvc.app.availablitymodule.service.AvailabilityService;
import com.example.availablitysvc.app.eventloggingmodule.dto.EventLoggingDto;
import com.example.availablitysvc.app.eventloggingmodule.entity.EventLogging;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import com.example.availablitysvc.app.eventloggingmodule.model.EventAvailabilityWrapper;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingModel;
import com.example.availablitysvc.app.eventloggingmodule.model.WrapperResponse;
import com.example.availablitysvc.app.eventloggingmodule.repository.EventLoggingRepository;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import jakarta.persistence.criteria.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;


@Service
public class EventLoggingServiceImpl implements EventLoggingService{

    @Autowired
    EventLoggingRepository eventLoggingRepository;
    @Autowired
    private AvailabilityService availabilityService;

    /**
     * @apiNote  eventLoggingModel to get the event details
     */
    @Override
    public ResponseEntity<WrapperResponse> logEvent(EventLoggingModel eventLoggingModel, String tenantId) {

        WrapperResponse response = new WrapperResponse();
        try {
            TenantContext.setTenantId(tenantId);
            eventLoggingModel.getItems().forEach(item -> {
                EventLogging eventLoggingEntity = new EventLogging();
                eventLoggingEntity.setEventType(eventLoggingModel.getEventType());
                eventLoggingEntity.setItemCode(item.getItemCode());
                eventLoggingEntity.setItemDescription(item.getItemDescription());
                eventLoggingEntity.setUnitOfMeasure(item.getUnitOfMeasure());
                eventLoggingEntity.setQuantity(item.getQuantity());
                eventLoggingEntity.setStatus(Status.Success);
                eventLoggingEntity.setEventLoggedTime(eventLoggingModel.getEventLoggedTime());
                eventLoggingEntity.setEventNature(eventLoggingModel.getEventNature() );
                eventLoggingEntity.setInventoryPostingGroup(item.getInventoryPostingGroup());
                EventAvailabilityWrapper eventAvailabilityWrapper = new EventAvailabilityWrapper();
                eventAvailabilityWrapper.setEventType(eventLoggingModel.getEventType());
                eventAvailabilityWrapper.setItemCode(item.getItemCode());
                eventAvailabilityWrapper.setItemDescription(item.getItemDescription());
                eventAvailabilityWrapper.setUnitOfMeasure(item.getUnitOfMeasure());
                eventAvailabilityWrapper.setQuantity(item.getQuantity());
                eventAvailabilityWrapper.setEventLoggedTime(eventLoggingModel.getEventLoggedTime());
                eventAvailabilityWrapper.setEventNature(eventLoggingModel.getEventNature() );
                eventAvailabilityWrapper.setInventoryPostingGroup(item.getInventoryPostingGroup());
                if (eventLoggingModel.getEventNature() == null || item.getInventoryPostingGroup() == null ||
                    eventLoggingModel.getEventNature().equals("") || item.getInventoryPostingGroup().equals("")
                ){
                    eventAvailabilityWrapper.setReason("Event Nature Or Inventory Posting Group is not provided Or incorrect");
                    failedLogEvent(eventAvailabilityWrapper, tenantId);
                    response.setErrorMessage("Event Logging Failed due to - Event Nature Or Inventory Posting Group is not provided Or incorrect");
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Event Nature Or Inventory Posting Group is not provided Or incorrect");
                }
                else {
                    availabilityService.availabilityCalculation(eventAvailabilityWrapper, tenantId);
                    try {
                        eventLoggingRepository.save(eventLoggingEntity);
                    } catch (Exception e) {
                        EventAvailabilityWrapper eventfailed = new EventAvailabilityWrapper();
                        eventAvailabilityWrapper.setEventType(eventLoggingModel.getEventType());
                        eventAvailabilityWrapper.setItemCode(item.getItemCode());
                        eventAvailabilityWrapper.setItemDescription(item.getItemDescription());
                        eventAvailabilityWrapper.setUnitOfMeasure(item.getUnitOfMeasure());
                        eventAvailabilityWrapper.setQuantity(item.getQuantity());
                        eventAvailabilityWrapper.setEventLoggedTime(eventLoggingModel.getEventLoggedTime());
                        eventAvailabilityWrapper.setEventNature(eventLoggingModel.getEventNature() );
                        eventAvailabilityWrapper.setInventoryPostingGroup(item.getInventoryPostingGroup());
                        eventAvailabilityWrapper.setReason("Event Logging Failed item not persisted in DB");
                        failedLogEvent(eventfailed, tenantId);
                        response.setErrorMessage("Event Logging Failed item not persisted in DB");
                        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Event Logging Failed due to - "+e.getMessage());
                    }
                }

            });

//            if(response.getErrorMessage() != null){
//                response.setErrorMessage("Event logged Failed");
//                System.out.println("Event logged Failed due to - "+response.getErrorMessage());
//                return ResponseEntity.badRequest().body(response);
//            }
//            else{
                response.setMessage("Event logged successfully");
                return ResponseEntity.ok(response);
//            }

        } catch (ResponseStatusException ex) {
            // bubble up the exact reason
            String reason = ex.getReason() != null ? ex.getReason() : "Availability calculation failed";
            WrapperResponse resp = new WrapperResponse();
            resp.setMessage("Event logged Failed: " + reason);
            return ResponseEntity.badRequest().body(resp);

        } catch (Exception e) {
            WrapperResponse resp = new WrapperResponse();
            resp.setMessage("Event logged Failed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
        finally {
            TenantContext.clear();
        }
    }

    public ResponseEntity<WrapperResponse> failedLogEvent(EventAvailabilityWrapper eventAvailabilityWrapper, String tenantId){

        try {
            TenantContext.setTenantId(tenantId);
            WrapperResponse response = new WrapperResponse();
                EventLogging failedEventLoggingEntity = new EventLogging();
                failedEventLoggingEntity.setEventType(eventAvailabilityWrapper.getEventType());
                failedEventLoggingEntity.setItemCode(eventAvailabilityWrapper.getItemCode());
                failedEventLoggingEntity.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                failedEventLoggingEntity.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                failedEventLoggingEntity.setQuantity(eventAvailabilityWrapper.getQuantity());
                failedEventLoggingEntity.setStatus(Status.Failed);
                failedEventLoggingEntity.setReason(eventAvailabilityWrapper.getReason());
                failedEventLoggingEntity.setEventLoggedTime(eventAvailabilityWrapper.getEventLoggedTime());

                eventLoggingRepository.save(failedEventLoggingEntity);
            response.setErrorMessage("Event logged Failed");
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            WrapperResponse response = new WrapperResponse();
            response.setErrorMessage("Event logged Failed");
            return ResponseEntity.badRequest().body(response);
        } finally {
            TenantContext.clear();
        }
    }

    @Override
    public Page<EventLoggingDto> getEventLoggingDataWithFilters(
            String searchText,
            List<Status> statuses,
            List<EventType> eventTypes,
            String tenantId,
            Pageable pageable) {

        // Use system default timezone (server’s timezone) instead of hardcoding India
        ZoneId zone = ZoneId.systemDefault();
        LocalDate today = LocalDate.now(zone);

        // start: 00:00 of today, end: 00:00 of next day
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime startOfNextDay = today.plusDays(1).atStartOfDay();
        return getDataWithFilters(searchText, statuses, eventTypes, startOfDay, startOfNextDay, tenantId,
                PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.DESC, "eventLoggedTime")));
    }

    @Override
    public Page<EventLoggingDto> getHistoricDataWithFilters(
            String searchText,
            List<Status> statuses,
            List<EventType> eventTypes,
            LocalDateTime from,
            LocalDateTime to,
            String tenantId,
            Pageable pageable) {
            return getDataWithFilters(searchText, statuses, eventTypes, from, to, tenantId, PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.DESC, "eventLoggedTime")));
    }


public Page<EventLoggingDto> getDataWithFilters(
        String searchText,
        List<Status> statuses,
        List<EventType> eventTypes,
        LocalDateTime from,
        LocalDateTime to,
        String tenantId,
        Pageable pageable) {

    LocalDateTime fromNorm = from;
    LocalDateTime toNorm = to;
    if (fromNorm != null && toNorm != null && fromNorm.isAfter(toNorm)) {
        LocalDateTime tmp = fromNorm;
        fromNorm = toNorm;
        toNorm = tmp;
    }

    final String q = (searchText == null) ? null : searchText.trim().toLowerCase();
    final LocalDateTime fFrom = fromNorm;
    final LocalDateTime fTo = toNorm;

    List<Specification<EventLogging>> parts = new ArrayList<>();

    if (q != null && !q.isBlank()) {
        parts.add((root, cq, cb) -> {
            Predicate p1 = cb.like(cb.lower(root.get("itemCode")), "%" + q + "%");
            Predicate p2 = cb.like(cb.lower(root.get("itemDescription")), "%" + q + "%");
            return cb.or(p1, p2);
        });
    }

    if (statuses != null && !statuses.isEmpty()) {
        parts.add((root, cq, cb) -> root.get("status").in(statuses));
    }

    if (eventTypes != null && !eventTypes.isEmpty()) {
        parts.add((root, cq, cb) -> root.get("eventType").in(eventTypes));
    }

    if (fFrom != null) {
        parts.add((root, cq, cb) -> cb.greaterThanOrEqualTo(root.get("eventLoggedTime"), fFrom));
    }

    if (fTo != null) {
        parts.add((root, cq, cb) -> cb.lessThanOrEqualTo(root.get("eventLoggedTime"), fTo));
    }

    Specification<EventLogging> spec =
            parts.isEmpty() ? ((root, cq, cb) -> cb.conjunction())
                    : Specification.allOf(parts);

    TenantContext.setTenantId(tenantId);
    try {
        Page<EventLogging> page = eventLoggingRepository.findAll(spec, pageable);
        return page.map(this::mapToDto);

    } finally {
        TenantContext.clear();
    }
}

    private EventLoggingDto mapToDto(EventLogging entity) {
        EventLoggingDto eventLoggingDto = new EventLoggingDto();
        eventLoggingDto.setEventId(entity.getEventId());
        eventLoggingDto.setEventType(entity.getEventType());
        eventLoggingDto.setItemCode(entity.getItemCode());
        eventLoggingDto.setQuantity(entity.getQuantity());
        eventLoggingDto.setUnitOfMeasure(entity.getUnitOfMeasure());
        eventLoggingDto.setReason(entity.getReason());
        eventLoggingDto.setStatus(entity.getStatus());
        eventLoggingDto.setEventLoggedTime(entity.getEventLoggedTime());
        eventLoggingDto.setItemDescription(entity.getItemDescription());
        return eventLoggingDto;
    }
}
