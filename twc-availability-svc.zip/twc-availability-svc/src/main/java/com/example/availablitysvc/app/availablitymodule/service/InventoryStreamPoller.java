package com.example.availablitysvc.app.availablitymodule.service;

import com.example.availablitysvc.app.availablitymodule.model.InventoryEvent;
import com.example.availablitysvc.app.availablitymodule.model.InventoryMessage;
import com.example.availablitysvc.app.availablitymodule.model.StreamKeys;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import io.lettuce.core.RedisCommandExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.stream.*;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class InventoryStreamPoller {

    private final RedisTemplate<String, Object> redis;
    private final Consumer consumer;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_DATE_TIME;

    public InventoryStreamPoller(RedisTemplate<String, Object> redis,
                                 @Value("${inventory.consumer.name:c1}") String consumerName) {
        this.redis = redis;
        this.consumer = Consumer.from(StreamKeys.GROUP, consumerName);

        try {
            RedisConnection connection = redis.getRequiredConnectionFactory().getConnection();

            // Get the list of groups directly
            List<StreamInfo.XInfoGroup> groups = connection.streamCommands()
                    .xInfoGroups(StreamKeys.STREAM.getBytes(StandardCharsets.UTF_8)).toList();

            boolean groupExists = groups.stream()
                    .anyMatch(g -> StreamKeys.GROUP.equals(g.groupName()));

            if (!groupExists) {
                connection.streamCommands().xGroupCreate(
                        StreamKeys.STREAM.getBytes(StandardCharsets.UTF_8),
                        StreamKeys.GROUP,
                        ReadOffset.from("0"),
                        true  // MKSTREAM
                );
                log.info("Redis stream group '{}' created for '{}' at {}",
                        StreamKeys.GROUP, StreamKeys.STREAM, LocalDateTime.now());
            } else {
                log.info("Redis stream group '{}' already exists for '{}', skipping creation",
                        StreamKeys.GROUP, StreamKeys.STREAM);
            }
            connection.close();
        } catch (Exception e) {
            log.warn("Redis group creation failed for stream {}: {}", StreamKeys.STREAM, e.getMessage(), e);
        }
    }

    /** Poll messages (blocks ≤ block), maps to InventoryMessage, DOES NOT ack. */
    public List<InventoryMessage> pollOnce(Duration block, int count) {
        List<MapRecord<String, Object, Object>> records = redis.opsForStream().read(
                consumer,
                StreamReadOptions.empty().count(count).block(block),
                StreamOffset.create(StreamKeys.STREAM, ReadOffset.lastConsumed())
        );

        if (records == null || records.isEmpty()) {
            return Collections.emptyList();
        }

        return records.stream()
                .map(this::mapToInventoryMessage)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    /** Ack a single message by id. */
    public void ack(String messageId) {
        redis.opsForStream().acknowledge(StreamKeys.STREAM, StreamKeys.GROUP, RecordId.of(messageId));
        log.debug("Acknowledged message {}", messageId);
    }

    /** Ack many messages in one batch. */
    public void ackAll(List<String> ids) {
        if (ids == null || ids.isEmpty()) return;

        RecordId[] recordIds = ids.stream().map(RecordId::of).toArray(RecordId[]::new);
        redis.opsForStream().acknowledge(StreamKeys.STREAM, StreamKeys.GROUP, recordIds);
        log.debug("Acknowledged {} messages", ids.size());
    }

    private InventoryMessage mapToInventoryMessage(MapRecord<String, Object, Object> record) {
        try {
            Map<Object, Object> m = record.getValue();

            String itemCode             = asString(m.get("itemCode"));
            String itemDescription      = asString(m.get("itemDescription"));
            BigDecimal quantity         = parseBigDecimal(asString(m.get("quantity")));
            String unitOfMeasureCode    = asString(m.get("unitOfMeasureCode"));
            EventType eventType         = parseEnum(EventType.class, asString(m.get("eventType")));
            LocalDateTime eventLoggedTime = parseDate(asString(m.get("eventLoggedTime")));
            EventNature eventNature     = parseEnum(EventNature.class, asString(m.get("eventNature")));
            String categoryCode         = asString(m.get("categoryCode"));
            String inventoryPostingGroup= asString(m.get("inventoryPostingGroup"));
            String tenantId             = asString(m.get("tenantId"));

            InventoryEvent event = new InventoryEvent(
                    itemCode,
                    itemDescription,
                    quantity,
                    unitOfMeasureCode,
                    eventType,
                    eventLoggedTime,
                    eventNature,
                    categoryCode,
                    inventoryPostingGroup,
                    tenantId
            );

            return new InventoryMessage(record.getId().getValue(), event);
        } catch (Exception e) {
            log.error("Failed to map record {}: {}", record, e.getMessage(), e);
            return null; // skip faulty message instead of crashing
        }
    }

    private static String asString(Object o) {
        return o == null ? null : o.toString();
    }

    private static BigDecimal parseBigDecimal(String value) {
        try {
            return value != null ? new BigDecimal(value) : null;
        } catch (NumberFormatException e) {
            log.warn("Invalid BigDecimal value: {}", value);
            return null;
        }
    }

    private static LocalDateTime parseDate(String value) {
        try {
            return value != null ? LocalDateTime.parse(value, DATE_FORMATTER) : null;
        } catch (Exception e) {
            log.warn("Invalid date value: {}", value);
            return null;
        }
    }

    private static <E extends Enum<E>> E parseEnum(Class<E> enumType, String value) {
        try {
            return value != null ? Enum.valueOf(enumType, value) : null;
        } catch (IllegalArgumentException e) {
            log.warn("Invalid enum value {} for {}", value, enumType.getSimpleName());
            return null;
        }
    }
}
