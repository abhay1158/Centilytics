package com.example.availablitysvc.app.storeonboardingmodule.repository;

import com.example.availablitysvc.app.storeonboardingmodule.entity.TenantDbConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantDbConfigRepository extends JpaRepository<TenantDbConfig, String> {
}
