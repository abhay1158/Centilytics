package com.example.availablitysvc.app.availablitymodule.model;


import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class AvailabilityChildItem {
    private UUID childItemId;
    private String itemCode;
    private String itemDescription;
    private String unitOfMeasureCode;
    private BigDecimal quantityPer;
    private BigDecimal availability;

}
