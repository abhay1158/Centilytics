package com.example.availablitysvc.app.storeonboardingmodule.controller;

import com.example.availablitysvc.twccore.master.entity.TenantInfo;
import com.example.availablitysvc.app.storeonboardingmodule.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.availablitysvc.app.storeonboardingmodule.dto.TenantRequestDto;

@RestController
@RequestMapping("/api/tenants")
public class TenantController {

    @Autowired
    private TenantService tenantService;

    @Operation(
            summary = "Create a new tenant",
            description = "Onboards a new tenant by creating a tenant record and associated database. " +
                    "Only tenantId is required in the request body; other fields are set internally.",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Tenant request containing only tenantId",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = TenantRequestDto.class)
                    )
            ),
            responses = {
                    @ApiResponse(responseCode = "200", description = "Tenant created successfully",
                            content = @Content(mediaType = "application/json", schema = @Schema(implementation = TenantInfo.class))),
                    @ApiResponse(responseCode = "400", description = "Invalid tenant ID or input data",
                            content = @Content(schema = @Schema(hidden = true))),
                    @ApiResponse(responseCode = "500", description = "Internal server error during database creation or migration",
                            content = @Content(schema = @Schema(hidden = true)))
            }
    )
    @PostMapping
    public ResponseEntity<TenantInfo> createTenant(@RequestBody TenantRequestDto request) {
        System.out.println("createTenant:------- " + request.getTenantId());
        try {
            TenantInfo createdTenant = tenantService.createTenant(
                    new TenantInfo(request.getTenantId()) // pass only tenantId, other values set in service
            );
            return ResponseEntity.ok(createdTenant);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @Operation(
            summary = "Delete an existing tenant",
            description = "Deboards a tenant by deleting its record and associated database",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Tenant deleted successfully"),
                    @ApiResponse(responseCode = "404", description = "Tenant not found"),
                    @ApiResponse(responseCode = "500", description = "Internal server error during deletion")
            }
    )
    @DeleteMapping("/{tenantId}")
    public ResponseEntity<Void> deleteTenant(@PathVariable("tenantId") String tenantId) {
        try {
            tenantService.deleteTenant(tenantId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}