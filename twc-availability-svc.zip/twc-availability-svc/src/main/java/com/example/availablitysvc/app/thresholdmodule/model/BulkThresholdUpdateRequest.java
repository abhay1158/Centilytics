package com.example.availablitysvc.app.thresholdmodule.model;


import lombok.Data;

import java.util.List;

@Data
public class BulkThresholdUpdateRequest {
    private List<CategoryThresholdUpdate> updates;

    @Data
    public static class CategoryThresholdUpdate {
        private String itemCategoryCode;
        private Integer minimumThresholdValue;
    }
}