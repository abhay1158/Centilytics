package com.example.availablitysvc.twccore.master.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "tenant_db_config")
public class TenantInfo {
    @Id
    @Column(name = "tenant_id")
    @Schema(description = "Unique identifier for the tenant", example = "S057")
    private String tenantId;

    @Column(name = "jdbc_url")
    @Schema(description = "JDBC URL for the tenant's database", example = "jdbc:postgresql://localhost:5432/tenant_S057")
    private String jdbcUrl;

    @Schema(description = "Database username for the tenant", example = "user123")
    private String username;

    @Schema(description = "Database password for the tenant", example = "pass123")
    private String password;

    public TenantInfo(String tenantId) {
        this.tenantId = tenantId;
    }
}
