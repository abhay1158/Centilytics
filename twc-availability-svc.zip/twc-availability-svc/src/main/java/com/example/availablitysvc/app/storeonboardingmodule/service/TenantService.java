package com.example.availablitysvc.app.storeonboardingmodule.service;

import com.example.availablitysvc.twccore.master.entity.TenantInfo;
import com.example.availablitysvc.twccore.master.locationmodule.repository.LocationRepository;
import com.example.availablitysvc.twccore.master.repository.TenantInfoRepository;
import liquibase.integration.spring.SpringLiquibase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;

@Service
public class TenantService {

    @Autowired
    private TenantInfoRepository repository;

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private DataSource masterDataSource;

    @Value("${tenant-creation.jdbcUrl}")
    private String baseJdbcUrl;

    @Value("${tenant-creation.username}")
    private String username;

    @Value("${tenant-creation.password}")
    private String password;

    public TenantInfo createTenant(TenantInfo tenant) {
        if (tenant.getTenantId() == null || tenant.getTenantId().trim().isEmpty()) {
            throw new IllegalArgumentException("Tenant ID is required");
        }

        // Construct the full jdbcUrl by appending tenantId to the base jdbcUrl
        String fullJdbcUrl = baseJdbcUrl + "tenant_" + tenant.getTenantId();

        // Set the constructed jdbcUrl, username, and password to the tenant object
        tenant.setJdbcUrl(fullJdbcUrl);
        tenant.setUsername(username);
        tenant.setPassword(password);

        TenantInfo saved = repository.save(tenant);
        createTenantDatabase(tenant.getTenantId());
        runLiquibaseMigration(tenant);
        return saved;
    }

    public void deleteTenant(String tenantId) { // Changed to tenantId
        repository.deleteById(tenantId);
        locationRepository.deleteById(tenantId);
    }

    private void createTenantDatabase(String dbName) {
        try {
            JdbcTemplate jdbcTemplate = new JdbcTemplate(masterDataSource);
            jdbcTemplate.execute("CREATE DATABASE \"" + "tenant_"+dbName + "\"");
        } catch (Exception e) {
            if (e.getMessage().contains("already exists")) {
                System.out.println("Database " + dbName + " already exists.");
            } else {
                throw new RuntimeException("Failed to create database " + dbName, e);
            }
        }
    }

    private void runLiquibaseMigration(TenantInfo tenant) { // Changed to TenantInfo
        try {
            DataSource dataSource = new DriverManagerDataSource(
                    tenant.getJdbcUrl(), tenant.getUsername(), tenant.getPassword());
            SpringLiquibase liquibase = new SpringLiquibase();
            liquibase.setChangeLog("classpath:db/changelog/db.changelog-tenant.yaml");
            liquibase.setDataSource(dataSource);
            liquibase.afterPropertiesSet();
        } catch (Exception e) {
            throw new RuntimeException("Failed to run Liquibase migration for tenant " + tenant.getTenantId(), e);
        }
    }

    private String extractDbName(String jdbcUrl) {
        String dbName = jdbcUrl.substring(jdbcUrl.lastIndexOf('/') + 1);
        return dbName.replace("tenant_", "");
    }
}