package com.example.availablitysvc.app.availablitymodule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class CustomBomGroup {
    private String customBomGroupCode;
    private String customBomCode;
    private List<ChildItem> childItems;

    @Override
    public String toString() {
        return "CustomBomGroup{" +
                "customBomGroupCode='" + customBomGroupCode + '\'' +
                ", customBomCode='" + customBomCode + '\'' +
                ", childItems=" + childItems +
                '}';
    }
}
