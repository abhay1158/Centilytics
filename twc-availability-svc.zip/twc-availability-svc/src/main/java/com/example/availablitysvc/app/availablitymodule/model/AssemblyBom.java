package com.example.availablitysvc.app.availablitymodule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AssemblyBom {
    private String parentItemId;
    private String parentDescription;
    private String divisionCode;
    private String baseUnitOfMeasure;
    private List<ChildItem> childItems;
    private boolean presentCustomBOM;

    @Override
    public String toString() {
        return "AssemblyBom{" +
                "parentItemId='" + parentItemId + '\'' +
                ", parentDescription='" + parentDescription + '\'' +
                ", divisionCode='" + divisionCode + '\'' +
                ", baseUnitOfMeasure='" + baseUnitOfMeasure + '\'' +
                ", childItems=" + childItems +
                ", presentCustomBOM=" + presentCustomBOM +
                '}';
    }
}
