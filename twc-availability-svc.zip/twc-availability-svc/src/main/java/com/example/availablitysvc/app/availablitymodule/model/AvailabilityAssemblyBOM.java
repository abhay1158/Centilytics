package com.example.availablitysvc.app.availablitymodule.model;


import lombok.Data;

import java.util.List;

@Data
public class AvailabilityAssemblyBOM {
    private String parentItemId;
    private String parentDescription;
    private String divisionCode;
    private String baseUnitOfMeasure;
    private boolean presentCustomBOM;
    private String customBomGroupCode;
    private List<AvailabilityChildItem> childItems;
}
