package com.example.availablitysvc.app.availablitymodule.service;

import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailability;
import com.example.availablitysvc.app.availablitymodule.entity.StoreCustomBomMapping;
import com.example.availablitysvc.app.availablitymodule.model.AssemblyBom;
import com.example.availablitysvc.app.availablitymodule.model.ChildItem;
import com.example.availablitysvc.app.availablitymodule.model.CustomBomGroup;
import com.example.availablitysvc.app.availablitymodule.model.InventoryMessage;
import com.example.availablitysvc.app.availablitymodule.repository.ItemAvailabilityRepository;
import com.example.availablitysvc.app.availablitymodule.repository.StoreCustomBomMappingRepository;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class InventoryScheduler {

    @Autowired
    private InventoryStreamPoller poller;

    @Autowired
    private ItemAvailabilityRepository itemAvailabilityRepository;

    @Autowired
    private WebClientCallBomService webClientCallBomService;

    @Autowired
    private StoreCustomBomMappingRepository storeCustomBomMappingRepository; // Add if needed

//    @Autowired
//    private AvailabilityService availabilityService;

    @Scheduled(fixedRate = 600000)
    public void processInventoryQueue() {
        try {
            System.out.println("Reverse BOM Mapping - Started");
            List<InventoryMessage> messages = poller.pollOnce(Duration.ofSeconds(10), 5000);

            Map<String, List<InventoryMessage>> byTenant = messages.stream()
                    .collect(Collectors.groupingBy(m -> m.event().tenantId()));

            for (Map.Entry<String, List<InventoryMessage>> entry : byTenant.entrySet()) {
                String tenantId = entry.getKey();
                TenantContext.setTenantId(tenantId);
                try {
                    for (InventoryMessage msg : entry.getValue()) {
                        var e = msg.event();
                        ItemAvailability rm = itemAvailabilityRepository.findById(e.itemCode())
                                .orElse(new ItemAvailability());
                        rm.setItemId(e.itemCode());
                        rm.setItemDescription(e.itemDescription());
                        rm.setUnitOfMeasure(e.unitOfMeasureCode());
                        rm.setCategoryCode(e.categoryCode());
                        rm.setInventoryPostingGroup(e.inventoryPostingGroup());
                        if (e.eventNature() == EventNature.IN) {
                            rm.setQuantity(rm.getQuantity().add(e.quantity()));
                        } else if (e.eventNature() == EventNature.OUT) {
                            rm.setQuantity(rm.getQuantity().subtract(e.quantity()));
                        }
                        rm.setLastUpdatedDateAndTime(e.eventLoggedTime());
                        itemAvailabilityRepository.save(rm);

                        poller.ack(msg.id());
                    }

                    recalculateFgAvailability(tenantId);
                    System.out.println("Scheduler executed...");
                } finally {
                    TenantContext.clear();
                }
            }
        } catch (RedisConnectionFailureException e) {
            System.err.println("Failed to connect to Redis: " + e.getMessage());
            // Optionally retry or log for further investigation
        } catch (Exception e) {
            System.err.println("Unknown Exception occurred: " + e.getMessage());
        }
    }

    public void recalculateFgAvailability(String tenantId) {
        List<ItemAvailability> fgs = itemAvailabilityRepository.findAllByInventoryPostingGroup("FG", PageRequest.of(0, Integer.MAX_VALUE)).getContent();

        for (ItemAvailability fg : fgs) {
            AssemblyBom bom = webClientCallBomService.getAssemblyBom(fg.getItemId());

            if(bom.isPresentCustomBOM()){
                CustomBomGroup customBomGroup = getCustomBomData(tenantId, fg.getItemId());
                if (customBomGroup.getChildItems() == null || customBomGroup.getChildItems().isEmpty()) {
                    continue;
                }
                BigDecimal minProducible = BigDecimal.valueOf(Integer.MAX_VALUE);
                for (ChildItem child : customBomGroup.getChildItems()) {
                    ItemAvailability rm = itemAvailabilityRepository.findById(child.getItemCode())
                            .orElseThrow(() -> new IllegalArgumentException("RM not found: " + child.getItemCode()));
                    BigDecimal producible = rm.getQuantity().divide(child.getQuantityPer(), 0, BigDecimal.ROUND_DOWN);
                    minProducible = minProducible.min(producible);
                }
                fg.setAvailability(minProducible);

            }
            else {
                if (bom.getChildItems() == null || bom.getChildItems().isEmpty()) {
                    continue;
                }

                BigDecimal minProducible = BigDecimal.valueOf(Integer.MAX_VALUE);
                for (ChildItem child : bom.getChildItems()) {
                    ItemAvailability rm = itemAvailabilityRepository.findById(child.getItemCode())
                            .orElseThrow(() -> new IllegalArgumentException("RM not found: " + child.getItemCode()));
                    BigDecimal producible = rm.getQuantity().divide(child.getQuantityPer(), 0, BigDecimal.ROUND_DOWN);
                    minProducible = minProducible.min(producible);
                }
                fg.setAvailability(minProducible);
            }
            fg.setLastUpdatedDateAndTime(LocalDateTime.now());
            itemAvailabilityRepository.save(fg);
        }
    }

    public CustomBomGroup getCustomBomData(String tenantId,String itemId) {
        String customBomGroupCode = getStoreCustomBomMapping(tenantId);
        List<CustomBomGroup> customBomGroups = customBomData(itemId);
        return customBomGroups.stream()
                .filter(g -> Objects.equals(customBomGroupCode, g.getCustomBomGroupCode()))
                .findFirst()
                .orElse(null);
    }

    public String getStoreCustomBomMapping(String tenantId) {
        try{
            TenantContext.setTenantId("twc_catalog");
            StoreCustomBomMapping storeCustomBomMapping = storeCustomBomMappingRepository.findByLocationCode(tenantId);
            return storeCustomBomMapping.getCustomBomGroupCode();
        }finally {
            TenantContext.clear();
        }
    }

    public List<CustomBomGroup> customBomData(String itemId) {
        List<CustomBomGroup> customBomGroups = webClientCallBomService.getCustomBom(itemId);
        return customBomGroups;
    }

}