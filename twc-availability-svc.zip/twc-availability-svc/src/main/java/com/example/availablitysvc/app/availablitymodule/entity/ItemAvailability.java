package com.example.availablitysvc.app.availablitymodule.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "item_availability")
public class ItemAvailability {

    @Id
    @Column(name = "item_id", nullable = false, updatable = false)
    private String itemId;

    @Column(name = "item_description")
    private String itemDescription;

    @Column(name = "unit_of_measure")
    private String unitOfMeasure;

    @Column(name = "quantity")
    private BigDecimal quantity;

    @Column(name = "category_code")
    private String categoryCode;

    @Column(name = "inventory_posting_group")
    private String inventoryPostingGroup;

    @Column(name = "availability")
    private BigDecimal availability;

    @Column(name = "last_updated_date_and_time")
    private LocalDateTime lastUpdatedDateAndTime;
}
