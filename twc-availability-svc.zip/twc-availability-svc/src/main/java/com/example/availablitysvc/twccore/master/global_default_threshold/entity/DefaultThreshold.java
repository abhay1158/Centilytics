package com.example.availablitysvc.twccore.master.global_default_threshold.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "threshold")
public class DefaultThreshold {
    @Id
    @Column(name = "item_category_code")
    private String itemCategoryCode;

    @Column(name = "base_unit_of_measure")
    private String baseUnitOfMeasure;

    @Column(name = "inventory_posting_group")
    private String inventoryPostingGroup;

    @Column(name = "threshold_value")
    private Integer thresholdValue;
}
