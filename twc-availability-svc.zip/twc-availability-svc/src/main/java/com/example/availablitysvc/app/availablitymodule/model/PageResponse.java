package com.example.availablitysvc.app.availablitymodule.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PageResponse<T> {
    private java.util.List<T> content;
    public java.util.List<T> getContent() { return content; }
    public void setContent(java.util.List<T> content) { this.content = content; }
}

