package com.example.availablitysvc.app.eventloggingmodule.model;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
public class EventLoggingFilterRequestWithDate {
    private List<Status> status;
    private List<EventType> eventTypes;
    private String searchText;

    private LocalDateTime from;
    private LocalDateTime to;

    private Integer page;
    private Integer size;
    private String sort;
}
