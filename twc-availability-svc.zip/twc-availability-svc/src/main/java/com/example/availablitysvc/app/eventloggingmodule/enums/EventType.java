package com.example.availablitysvc.app.eventloggingmodule.enums;

import lombok.NoArgsConstructor;

//@AllArgsConstructor
@NoArgsConstructor
public enum EventType {
    Purchase_GRN,
    Purchase_Return,
    Physical_Counting,
    Wastage,
    Transfer_In,
    Inter_Store_Transfer,
    Production_Entry_Raw_Material,
    Production_Entry


//    PURCHASEGRN("Purchase GRN"),
//    WASTAGE("Wastage");
//
//    private final String displayName;
//
//    EventType(String displayName) {
//        this.displayName = displayName;
//    }
//
//    public String getDisplayName() {
//        return displayName;
//    }
}
