package com.example.availablitysvc.twccore.tenant;

import com.example.availablitysvc.twccore.master.entity.TenantInfo;
import com.example.availablitysvc.twccore.master.repository.TenantInfoRepository;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class TenantDataSourceProvider {

    private final TenantInfoRepository tenantRepo;
    private final Map<String, HikariDataSource> cache = new ConcurrentHashMap<>();

    public TenantDataSourceProvider(TenantInfoRepository tenantRepo) {
        this.tenantRepo = tenantRepo;
    }

    public HikariDataSource getDataSource(String tenantId) {
        return cache.computeIfAbsent(tenantId, this::createDataSource);
    }

    private HikariDataSource createDataSource(String tenantId) {
        TenantInfo info = tenantRepo.findById(tenantId)
                .orElseThrow(() -> new IllegalArgumentException("Unknown tenant: " + tenantId));
        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(info.getJdbcUrl());
        cfg.setUsername(info.getUsername());
        cfg.setPassword(info.getPassword());
        cfg.setMaximumPoolSize(5);
        cfg.setMinimumIdle(0); // don’t hold idles
        cfg.setPoolName("tenant-" + tenantId);
        cfg.setLeakDetectionThreshold(15_000);  // optional: help detect leaks
        return new HikariDataSource(cfg);
    }

    public void close(String tenantId) {
        HikariDataSource ds = cache.remove(tenantId);
        if (ds != null) ds.close();
    }

    public void closeAll() {
        cache.values().forEach(DataSource::toString);
        cache.values().forEach(HikariDataSource::close);
        cache.clear();
    }
}
