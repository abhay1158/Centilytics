package com.example.availablitysvc.app.thresholdmodule.service;


import com.example.availablitysvc.app.thresholdmodule.entity.ThresholdEntity;
import com.example.availablitysvc.app.thresholdmodule.model.BulkThresholdUpdateRequest;
import com.example.availablitysvc.app.thresholdmodule.model.IndividualThresholdUpdateRequest;
import com.example.availablitysvc.app.thresholdmodule.model.ThresholdModel;
import com.example.availablitysvc.app.thresholdmodule.repository.ThresholdRepository;
import com.example.availablitysvc.twccore.master.global_default_threshold.entity.DefaultThreshold;
import com.example.availablitysvc.twccore.master.global_default_threshold.repository.GlobalThresholdRepository;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ThresholdService {

    @Autowired
    private ThresholdRepository thresholdRepository;


    @Autowired
    private GlobalThresholdRepository masterThresholdRepository;

    public Page<ThresholdModel> getThresholds(int page, int size, String search) {
        Page<ThresholdEntity> entities;

        Pageable pageable = PageRequest.of(page, size);

        if (search != null && !search.isBlank()) {
            entities = thresholdRepository.searchThresholds(search, pageable);
        } else {
            entities = thresholdRepository.findAll(pageable);
        }

        List<ThresholdModel> dtoList = entities.stream()
                .map(entity -> new ThresholdModel(
                        entity.getId(),
                        entity.getDescription(),
                        entity.getBaseUnitOfMeasure(),
                        entity.getInventoryPostingGroup(),
                        entity.getItemCategoryCode(),
                        entity.getMinimumThresholdValue()
                ))
                .toList();

        return new PageImpl<>(dtoList, entities.getPageable(), entities.getTotalElements());
    }


    public List<String> getDistinctItemCategoryCodes() {
        return thresholdRepository.findDistinctItemCategoryCodes();
    }

    public Page<ThresholdModel> getThresholdsByItemCategoryCodes(List<String> itemCategoryCodes, Pageable pageable) {
        return thresholdRepository.findByItemCategoryCodeIn(itemCategoryCodes, pageable)
                .map(entity -> new ThresholdModel(
                        entity.getId(),
                        entity.getDescription(),
                        entity.getBaseUnitOfMeasure(),
                        entity.getInventoryPostingGroup(),
                        entity.getItemCategoryCode(),
                        entity.getMinimumThresholdValue()
                ));
    }



    public void updateThresholdsInBulk(List<IndividualThresholdUpdateRequest> updateRequests) {
        for (IndividualThresholdUpdateRequest request : updateRequests) {
            ThresholdEntity entity = thresholdRepository.findById(request.getItemId())
                    .orElseThrow(() -> new RuntimeException("Item not found: " + request.getItemId()));

            entity.setMinimumThresholdValue(request.getMinimumThresholdValue());
            thresholdRepository.save(entity);
        }
    }
    public void bulkUpdateThresholdByCategory(List<BulkThresholdUpdateRequest.CategoryThresholdUpdate> updates) {
        for (BulkThresholdUpdateRequest.CategoryThresholdUpdate update : updates) {
            List<ThresholdEntity> entities = thresholdRepository.findByItemCategoryCode(update.getItemCategoryCode());
            for (ThresholdEntity entity : entities) {
                entity.setMinimumThresholdValue(update.getMinimumThresholdValue());
            }
            thresholdRepository.saveAll(entities);
        }
    }

    public Integer getThresholdValueById(String id) {
        Integer threshold = thresholdRepository.findMinimumThresholdValueById(id);
        return threshold;
    }

    public void resetThreshold(String tenantId, String itemCategoryCode) {
        TenantContext.setTenantId(tenantId);
        try {
            DefaultThreshold masterThreshold = masterThresholdRepository.findFirstByItemCategoryCode(itemCategoryCode)
                    .orElseThrow(() -> new IllegalArgumentException("No threshold found in master for category: " + itemCategoryCode));
            List<ThresholdEntity> tenantThresholds = thresholdRepository.findByItemCategoryCode(itemCategoryCode);
            for (ThresholdEntity tenantThreshold : tenantThresholds) {
                tenantThreshold.setMinimumThresholdValue(masterThreshold.getThresholdValue());
                tenantThreshold.setBaseUnitOfMeasure(masterThreshold.getBaseUnitOfMeasure());
                tenantThreshold.setInventoryPostingGroup(masterThreshold.getInventoryPostingGroup());
                thresholdRepository.save(tenantThreshold);
            }
        } catch (Exception e) {
            System.out.println("Exception Occurred");
            throw new RuntimeException(e);
        }finally {
            TenantContext.clear();
        }
    }

}
