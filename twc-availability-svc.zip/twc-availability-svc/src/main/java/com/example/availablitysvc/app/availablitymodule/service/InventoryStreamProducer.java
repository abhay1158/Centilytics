package com.example.availablitysvc.app.availablitymodule.service;

import java.util.LinkedHashMap;
import java.util.Map;

import com.example.availablitysvc.app.availablitymodule.model.InventoryEvent;
import com.example.availablitysvc.app.availablitymodule.model.StreamKeys;
import org.springframework.data.redis.connection.stream.RecordId;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class InventoryStreamProducer {
    private RedisTemplate<String, Object> redis;
    private static final String STREAM = "inventory:stream";

    public InventoryStreamProducer(RedisTemplate<String, Object> redis) {
        this.redis = redis;
    }

    public RecordId enqueue(InventoryEvent e) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("itemCode", e.itemCode());
        fields.put("itemDescription", e.itemDescription());
        fields.put("quantity", e.quantity() == null ? null : e.quantity().toPlainString());
        fields.put("unitOfMeasureCode", e.unitOfMeasureCode());
        fields.put("eventType", e.eventType() == null ? null : e.eventType().name());
        fields.put("eventLoggedTime", e.eventLoggedTime() == null ? null : e.eventLoggedTime().toString());
        fields.put("eventNature", e.eventNature() == null ? null : e.eventNature().name());
        fields.put("categoryCode", e.categoryCode());
        fields.put("inventoryPostingGroup", e.inventoryPostingGroup());
        fields.put("tenantId", e.tenantId());

        // Remove nulls (Redis stream fields must be non-null strings)
        fields.entrySet().removeIf(en -> en.getValue() == null);

        return redis.opsForStream()
                .add(StreamRecords.mapBacked(fields).withStreamKey(STREAM));
    }
}