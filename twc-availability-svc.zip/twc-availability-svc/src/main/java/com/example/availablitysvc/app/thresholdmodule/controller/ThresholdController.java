package com.example.availablitysvc.app.thresholdmodule.controller;

import com.example.availablitysvc.app.thresholdmodule.entity.ThresholdEntity;
import com.example.availablitysvc.app.thresholdmodule.model.BulkThresholdUpdateRequest;
import com.example.availablitysvc.app.thresholdmodule.model.IndividualThresholdUpdateRequest;
import com.example.availablitysvc.app.thresholdmodule.model.ThresholdModel;
import com.example.availablitysvc.app.thresholdmodule.service.ThresholdService;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/thresholds")
public class ThresholdController {

    @Autowired
    private ThresholdService thresholdService;

    @GetMapping
    public Page<ThresholdModel> getThresholds(
            @RequestHeader(name = "X-Tenant-ID") String tenantId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "20") int size,
            @RequestParam(name = "search", required = false) String search
    ) {
        try {
            TenantContext.setTenantId(tenantId);
            return thresholdService.getThresholds(page, size, search);
        } finally {
            TenantContext.clear();
        }
    }
    @GetMapping("/filters/item-category-codes")
    public List<String> getDistinctItemCategoryCodes(@RequestHeader(name = "X-Tenant-ID") String tenantId) {
        try {
            TenantContext.setTenantId(tenantId);
            return thresholdService.getDistinctItemCategoryCodes();
        } finally {
            TenantContext.clear();
        }
    }

    @PostMapping("/filter-by-category")
    public Page<ThresholdModel> getThresholdsByItemCategoryCodes(
            @RequestHeader(name = "X-Tenant-ID") String tenantId,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "20") int size,
            @RequestBody List<String> itemCategoryCodes
    ) {
        try {
            TenantContext.setTenantId(tenantId);
            Pageable pageable = PageRequest.of(page, size);
            return thresholdService.getThresholdsByItemCategoryCodes(itemCategoryCodes, pageable);
        } finally {
            TenantContext.clear();
        }
    }

    @PatchMapping("/update-threshold")
    public ResponseEntity<String> updateThresholdsInBulk(
            @RequestHeader("X-Tenant-ID") String tenantId,
            @RequestBody List<IndividualThresholdUpdateRequest> updateRequests
    ) {
        TenantContext.setTenantId(tenantId);
        thresholdService.updateThresholdsInBulk(updateRequests);
        TenantContext.clear();

        return ResponseEntity.ok("Thresholds updated successfully for provided items");
    }


    @PatchMapping("/bulk-update-by-category")
    public ResponseEntity<String> bulkUpdateThresholdByCategory(
            @RequestHeader("X-Tenant-ID") String tenantId,
            @RequestBody BulkThresholdUpdateRequest request
    ) {
        try {
            TenantContext.setTenantId(tenantId);
            thresholdService.bulkUpdateThresholdByCategory(request.getUpdates());
            return ResponseEntity.ok("Thresholds updated for provided item category codes.");
        } finally {
            TenantContext.clear();
        }
    }

    @PostMapping("/reset/{itemCategoryCode}")
    public ResponseEntity<Void> resetThreshold(
            @RequestHeader(name = "X-Tenant-ID") String tenantId,
            @PathVariable("itemCategoryCode") String itemCategoryCode
    ) {
        try {
            TenantContext.setTenantId(tenantId);
            thresholdService.resetThreshold(tenantId, itemCategoryCode);
            return ResponseEntity.ok().build();
        } finally {
            TenantContext.clear();
        }
    }

}
