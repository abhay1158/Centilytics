package com.example.availablitysvc.app.availablitymodule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChildItem {
    private UUID childItemId;
    private String itemCode;
    private String itemDescription;
    private String unitOfMeasureCode;
    private BigDecimal quantityPer;

    @Override
    public String toString() {
        return "ChildItem{" +
                "childItemId=" + childItemId +
                ", itemCode='" + itemCode + '\'' +
                ", itemDescription='" + itemDescription + '\'' +
                ", unitOfMeasureCode='" + unitOfMeasureCode + '\'' +
                ", quantityPer=" + quantityPer +
                '}';
    }
}
