package com.example.availablitysvc.app.availablitymodule.service;

import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailabilityHistoric;
import com.example.availablitysvc.app.availablitymodule.entity.StoreCustomBomMapping;
import com.example.availablitysvc.app.availablitymodule.model.*;
import com.example.availablitysvc.app.availablitymodule.entity.ItemAvailability;
import com.example.availablitysvc.app.availablitymodule.repository.ItemAvailabilityHistoricRepository;
import com.example.availablitysvc.app.availablitymodule.repository.ItemAvailabilityRepository;
import com.example.availablitysvc.app.availablitymodule.repository.StoreCustomBomMappingRepository;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;

import com.example.availablitysvc.app.eventloggingmodule.model.EventAvailabilityWrapper;

import com.example.availablitysvc.app.eventloggingmodule.service.EventLoggingServiceImpl;
import com.example.availablitysvc.app.thresholdmodule.entity.ThresholdEntity;
import com.example.availablitysvc.app.thresholdmodule.repository.ThresholdRepository;
import com.example.availablitysvc.app.thresholdmodule.service.ThresholdService;
import com.example.availablitysvc.twccore.master.global_default_threshold.entity.DefaultThreshold;
import com.example.availablitysvc.twccore.master.global_default_threshold.service.GlobalThresholdService;
import com.example.availablitysvc.twccore.tenant.TenantContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;


import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
public class AvailabilityService {
    @Autowired
    private ItemAvailabilityRepository itemAvailabilityRepository;
    @Autowired
    private ThresholdService thresholdService;
    @Autowired
    private final WebClientCallBomService webClientCallBomService;

    @Autowired
    private final InventoryStreamProducer producer;
    @Autowired
    private ItemAvailabilityHistoricRepository itemAvailabilityHistoricRepository;

    @Autowired
    private StoreCustomBomMappingRepository storeCustomBomMappingRepository;

    @Autowired
    private GlobalThresholdService globalThresholdService;

    @Autowired
    private ThresholdRepository thresholdRepository;

    @Autowired
    private InventoryScheduler inventoryScheduler;

    public AvailabilityService(WebClientCallBomService webClientCallBomService, InventoryStreamProducer producer) {
        this.webClientCallBomService = webClientCallBomService;
        this.producer = producer;
    }
    public void availabilityCalculation(EventAvailabilityWrapper eventAvailabilityWrapper, String tenantId) {
            try{
                ItemAvailability itemAvailability = new ItemAvailability();
                ItemAvailabilityHistoric itemAvailabilityHistoric = new ItemAvailabilityHistoric();
                BigDecimal threshold = BigDecimal.valueOf(thresholdService.getThresholdValueById(eventAvailabilityWrapper.getItemCode()));
                BigDecimal availability = getAvailabilityValue(eventAvailabilityWrapper.getItemCode(), tenantId);
                BigDecimal availableQuantity = getQuantityValue(eventAvailabilityWrapper.getItemCode(), tenantId);
                ItemAvailability allItemsInAvailabilityTable= getItemAvailabilityByItemId(eventAvailabilityWrapper.getItemCode(), tenantId);

                if(allItemsInAvailabilityTable !=null) {

                        AssemblyBom assemblyBom = assemblyBomData(eventAvailabilityWrapper.getItemCode());
                        boolean customBomFlag = isCustomBomAvailable(assemblyBom);
                        List<CustomBomGroup> customBom = null;
                        if (customBomFlag) {
                            customBom = customBomData(eventAvailabilityWrapper.getItemCode());
                        }
                        boolean isAssemblyBomAvailable = true;
                        if (assemblyBom.getChildItems().isEmpty() ||
                                assemblyBom.getChildItems() == null ||
                                assemblyBom.getChildItems().size() == 0) {
                            isAssemblyBomAvailable = false;
                        }
                        // When no custom bom available and no assembly bom available ITS RM ITEM And FG which are Not Bom Dependent
                        if (!customBomFlag && isAssemblyBomAvailable == false) {
                            if (eventAvailabilityWrapper.getEventNature().equals(EventNature.IN)) {
                                itemAvailability.setQuantity(availableQuantity.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailability.setAvailability(availability.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityRepository.updateAvailabilityAndQuantityByItemCode(eventAvailabilityWrapper.getItemCode(),
                                        itemAvailability.getAvailability(),itemAvailability.getQuantity(),
                                        itemAvailability.getLastUpdatedDateAndTime()
                                );
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                                inventoryScheduler.recalculateFgAvailability(tenantId);//recalculate FG availability
                            }
                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT) &&
                                    threshold.compareTo(availability) <= 0 &&
                                    eventAvailabilityWrapper.getInventoryPostingGroup().equals("FG")
                            ) {
                                itemAvailability.setAvailability(BigDecimal.valueOf(0.00));
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityRepository.updateAvailabilityByItemCode(eventAvailabilityWrapper.getItemCode(),
                                        itemAvailability.getAvailability(),
                                        itemAvailability.getLastUpdatedDateAndTime()
                                );
                                EventLoggingServiceImpl eventLoggingService = new EventLoggingServiceImpl();
                                eventAvailabilityWrapper.setReason("Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());
                                eventLoggingService.failedLogEvent(eventAvailabilityWrapper, tenantId);
                                throw new ResponseStatusException(BAD_REQUEST, "Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());
                            }
                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT)) {
                                itemAvailability.setQuantity(availableQuantity.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailability.setAvailability(availability.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityRepository.updateAvailabilityAndQuantityByItemCode(eventAvailabilityWrapper.getItemCode(),
                                        itemAvailability.getAvailability(),itemAvailability.getQuantity(),
                                        itemAvailability.getLastUpdatedDateAndTime()
                                );
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                                inventoryScheduler.recalculateFgAvailability(tenantId);//recalculate FG availability
                            }
                        }

                        // When assembly bom available but no custom bom available
                        else if (customBomFlag == false && isAssemblyBomAvailable == true) {
                            if (eventAvailabilityWrapper.getEventNature().equals(EventNature.IN)) {
                                InventoryEvent event = new InventoryEvent(
                                        eventAvailabilityWrapper.getItemCode(),
                                        eventAvailabilityWrapper.getItemDescription(),
                                        eventAvailabilityWrapper.getQuantity(),
                                        eventAvailabilityWrapper.getUnitOfMeasure(),
                                        eventAvailabilityWrapper.getEventType(),
                                        eventAvailabilityWrapper.getEventLoggedTime(),
                                        EventNature.IN,
                                        eventAvailabilityWrapper.getCategoryCode(),
                                        eventAvailabilityWrapper.getInventoryPostingGroup(),
                                        tenantId
                                );
                                producer.enqueue(event);
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                            }
                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT) && threshold.compareTo(availability) >= 0) {
                                InventoryEvent event = new InventoryEvent(
                                        eventAvailabilityWrapper.getItemCode(),
                                        eventAvailabilityWrapper.getItemDescription(),
                                        eventAvailabilityWrapper.getQuantity(),
                                        eventAvailabilityWrapper.getUnitOfMeasure(),
                                        eventAvailabilityWrapper.getEventType(),
                                        eventAvailabilityWrapper.getEventLoggedTime(),
                                        EventNature.OUT,
                                        eventAvailabilityWrapper.getCategoryCode(),
                                        eventAvailabilityWrapper.getInventoryPostingGroup(),
                                        tenantId
                                );
                                producer.enqueue(event);
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                            }
                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT) &&
                                    threshold.compareTo(availability) <= 0
                            ) {
                                itemAvailability.setAvailability(BigDecimal.valueOf(0.00));
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityRepository.updateAvailabilityByItemCode(eventAvailabilityWrapper.getItemCode(),
                                        itemAvailability.getAvailability(),
                                        itemAvailability.getLastUpdatedDateAndTime()
                                );
                                EventLoggingServiceImpl eventLoggingService = new EventLoggingServiceImpl();
                                eventAvailabilityWrapper.setReason("Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());
                                eventLoggingService.failedLogEvent(eventAvailabilityWrapper, tenantId);
                                throw new ResponseStatusException(BAD_REQUEST, "Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());

                            }
                        }
                        else if(customBomFlag==true){
                            //When custom bom available
                            if (eventAvailabilityWrapper.getEventNature().equals(EventNature.IN)) {
                                InventoryEvent event = new InventoryEvent(
                                        eventAvailabilityWrapper.getItemCode(),
                                        eventAvailabilityWrapper.getItemDescription(),
                                        eventAvailabilityWrapper.getQuantity(),
                                        eventAvailabilityWrapper.getUnitOfMeasure(),
                                        eventAvailabilityWrapper.getEventType(),
                                        eventAvailabilityWrapper.getEventLoggedTime(),
                                        EventNature.IN,
                                        eventAvailabilityWrapper.getCategoryCode(),
                                        eventAvailabilityWrapper.getInventoryPostingGroup(),
                                        tenantId
                                );
                                producer.enqueue(event);
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.add(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                            }
                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT) && threshold.compareTo(availability) >= 0) {
                                InventoryEvent event = new InventoryEvent(
                                        eventAvailabilityWrapper.getItemCode(),
                                        eventAvailabilityWrapper.getItemDescription(),
                                        eventAvailabilityWrapper.getQuantity(),
                                        eventAvailabilityWrapper.getUnitOfMeasure(),
                                        eventAvailabilityWrapper.getEventType(),
                                        eventAvailabilityWrapper.getEventLoggedTime(),
                                        EventNature.OUT,
                                        eventAvailabilityWrapper.getCategoryCode(),
                                        eventAvailabilityWrapper.getInventoryPostingGroup(),
                                        tenantId
                                );
                                producer.enqueue(event);
                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(availability.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setQuantity(availableQuantity.subtract(eventAvailabilityWrapper.getQuantity()));
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                            }

                            else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.OUT) &&
                                    threshold.compareTo(availability) <= 0 &&
                                    eventAvailabilityWrapper.getInventoryPostingGroup().equals("FG")
                            ) {
                                itemAvailability.setAvailability(BigDecimal.valueOf(0.00));
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityRepository.updateAvailabilityByItemCode(eventAvailabilityWrapper.getItemCode(),
                                        itemAvailability.getAvailability(),
                                        itemAvailability.getLastUpdatedDateAndTime()
                                );
                                EventLoggingServiceImpl eventLoggingService = new EventLoggingServiceImpl();
                                eventAvailabilityWrapper.setReason("Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());
                                eventLoggingService.failedLogEvent(eventAvailabilityWrapper, tenantId);
                                throw new ResponseStatusException(BAD_REQUEST, "Threshold value reached for item " + eventAvailabilityWrapper.getItemCode() + " - " + eventAvailabilityWrapper.getItemDescription());

                            }
                        }
                }
                else {
                    Optional<DefaultThreshold> defaultThreshold = globalThresholdService.getGlobalThresholdByItem(eventAvailabilityWrapper.getCategoryCode());

                    if (eventAvailabilityWrapper.getInventoryPostingGroup().equals("FG") &&
                            eventAvailabilityWrapper.getEventNature().equals(EventNature.IN) &&
                            eventAvailabilityWrapper.getQuantity().compareTo(BigDecimal.ZERO) >= 0)
                    {
                        //When FG item arrive with quantity and not present in db IT'S MENU CARD OF Store
                        ThresholdEntity thresholdEntity = new ThresholdEntity();
                        thresholdEntity.setId(eventAvailabilityWrapper.getItemCode());
                        thresholdEntity.setDescription(eventAvailabilityWrapper.getItemDescription());
                        thresholdEntity.setBaseUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                        thresholdEntity.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                        thresholdEntity.setItemCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                        thresholdEntity.setMinimumThresholdValue(defaultThreshold.map(DefaultThreshold::getThresholdValue).orElse(Integer.valueOf(0)));
                        thresholdRepository.save(thresholdEntity);

                        itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                        itemAvailability.setItemId(eventAvailabilityWrapper.getItemCode());
                        itemAvailability.setAvailability(eventAvailabilityWrapper.getQuantity());
                        itemAvailability.setQuantity(eventAvailabilityWrapper.getQuantity());
                        itemAvailability.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                        itemAvailability.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                        itemAvailability.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                        itemAvailability.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                        itemAvailabilityRepository.save(itemAvailability);

                        itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                        itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                        itemAvailabilityHistoric.setAvailability(eventAvailabilityWrapper.getQuantity());
                        itemAvailabilityHistoric.setQuantity(eventAvailabilityWrapper.getQuantity());
                        itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                        itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                        itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                        itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                        itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                    } else if (eventAvailabilityWrapper.getEventNature().equals(EventNature.IN)){
                                InventoryEvent event = new InventoryEvent(
                                        eventAvailabilityWrapper.getItemCode(),
                                        eventAvailabilityWrapper.getItemDescription(),
                                        eventAvailabilityWrapper.getQuantity(),
                                        eventAvailabilityWrapper.getUnitOfMeasure(),
                                        eventAvailabilityWrapper.getEventType(),
                                        eventAvailabilityWrapper.getEventLoggedTime(),
                                        EventNature.IN,
                                        eventAvailabilityWrapper.getCategoryCode(),
                                        eventAvailabilityWrapper.getInventoryPostingGroup(),
                                        tenantId
                                );
                                producer.enqueue(event);
                                itemAvailability.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailability.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailability.setAvailability(eventAvailabilityWrapper.getQuantity());
                                itemAvailability.setQuantity(eventAvailabilityWrapper.getQuantity());
                                itemAvailability.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailability.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailability.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailability.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityRepository.save(itemAvailability);

                                itemAvailabilityHistoric.setLastUpdatedDateAndTime(eventAvailabilityWrapper.getEventLoggedTime());
                                itemAvailabilityHistoric.setItemId(eventAvailabilityWrapper.getItemCode());
                                itemAvailabilityHistoric.setAvailability(eventAvailabilityWrapper.getQuantity());
                                itemAvailabilityHistoric.setQuantity(eventAvailabilityWrapper.getQuantity());
                                itemAvailabilityHistoric.setCategoryCode(eventAvailabilityWrapper.getCategoryCode());
                                itemAvailabilityHistoric.setItemDescription(eventAvailabilityWrapper.getItemDescription());
                                itemAvailabilityHistoric.setUnitOfMeasure(eventAvailabilityWrapper.getUnitOfMeasure());
                                itemAvailabilityHistoric.setInventoryPostingGroup(eventAvailabilityWrapper.getInventoryPostingGroup());
                                itemAvailabilityHistoricRepository.save(itemAvailabilityHistoric);
                    }
                }

            } catch (Exception e) {
                e.getMessage();
            }
    }
    public List<CustomBomGroup> customBomData(String itemId) {
        List<CustomBomGroup> customBomGroups = webClientCallBomService.getCustomBom(itemId);
        return customBomGroups;
    }

    public AssemblyBom assemblyBomData(String itemId) {
        AssemblyBom assemblyBoms = webClientCallBomService.getAssemblyBom(itemId);
        return assemblyBoms;
    }
    public boolean isCustomBomAvailable(AssemblyBom assemblyBom) {
        boolean customBomFlag = false;
        if(assemblyBom.isPresentCustomBOM()==true){
            customBomFlag=true;
        }
        return customBomFlag;
    }


    public String getStoreCustomBomMapping(String tenantId) {
        try{
            TenantContext.setTenantId("twc_catalog");
            StoreCustomBomMapping storeCustomBomMapping = storeCustomBomMappingRepository.findByLocationCode(tenantId);
            return storeCustomBomMapping.getCustomBomGroupCode();
        }finally {
            TenantContext.clear();
        }
    }

    public CustomBomGroup getCustomBomData(String tenantId,String itemId) {
            String customBomGroupCode = getStoreCustomBomMapping(tenantId);
            List<CustomBomGroup> customBomGroups = customBomData(itemId);
            return customBomGroups.stream()
                    .filter(g -> Objects.equals(customBomGroupCode, g.getCustomBomGroupCode()))
                    .findFirst()
                    .orElse(null);
    }



    public Page<ItemAvailability> searchLocations(String query, Pageable pageable, String tenantId) {

        try{
            TenantContext.setTenantId(tenantId);
        if (query == null || query.trim().isEmpty()) {
            return itemAvailabilityRepository.findAll(pageable);
        }
            return itemAvailabilityRepository.searchByItemIdOrDescription(query, pageable);

        }finally {
            TenantContext.clear();
        }
    }
    public Page<ItemAvailability> filterItems(List<String> inventoryGroups, List<String> categoryCodes,
                                              Pageable pageable, LocalDateTime availabilityDateAndTime, String tenantId) {
        try{
            TenantContext.setTenantId(tenantId);
            if(availabilityDateAndTime!=null){
                return itemAvailabilityHistoricRepository.filterByMultipleInventoryGroupsAndCategoryCodesByDate(
                        inventoryGroups,
                        categoryCodes,
                        availabilityDateAndTime,
                        PageRequest.of(0, 1)
                );
            }
        return itemAvailabilityRepository.filterByMultipleInventoryGroupsAndCategoryCodes(
                inventoryGroups,
                categoryCodes,
                pageable
        );
        }finally {
            TenantContext.clear();
        }
    }
    public List<String> getDistinctInventoryPostingGroups(String tenantId) {
        try {
            TenantContext.setTenantId(tenantId);
            return itemAvailabilityRepository.findDistinctInventoryPostingGroups();
        }finally {
            TenantContext.clear();
        }
    }

    public Page<ItemAvailability> getAllFgItemAvailability(String tenantId, Pageable pageable, LocalDateTime availabilityDateAndTime) {
        try{
            TenantContext.setTenantId(tenantId);
            if(availabilityDateAndTime!=null){
                Page<ItemAvailability> page = itemAvailabilityHistoricRepository.findAllByInventoryPostingGroupByDate("FG", availabilityDateAndTime, PageRequest.of(0, 1));
                return page;
            }
            else{
                Page<ItemAvailability> page = itemAvailabilityRepository.findAllByInventoryPostingGroup("FG", PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "itemId")));
                return page;
            }

        }finally {
            TenantContext.clear();
        }
    }

    private ItemModel mapToDto(ItemAvailability entity) {
        ItemModel itemModel = new ItemModel();
            itemModel.setItemId(entity.getItemId());
            itemModel.setItemDescription(entity.getItemDescription());
            itemModel.setUnitOfMeasure(entity.getUnitOfMeasure());
            itemModel.setQuantity(entity.getQuantity());
            itemModel.setCategoryCode(entity.getCategoryCode());
            itemModel.setAvailability(entity.getAvailability());
            itemModel.setLastUpdatedDateAndTime(entity.getLastUpdatedDateAndTime());
        return itemModel;
    }

    public BigDecimal getAvailabilityValue(String itemId, String tenantId) {
        ItemAvailability ia = itemAvailabilityRepository.findItemAvailabilityByItemId(itemId);
        return Optional.ofNullable(ia)
                .map(ItemAvailability::getAvailability)
                .orElse(BigDecimal.ZERO);
    }

    public BigDecimal getQuantityValue(String itemId, String tenantId) {
            BigDecimal itemQuantityValue = itemAvailabilityRepository.findItemQuantityByItemId(itemId);
            return itemQuantityValue;

    }

    public ItemAvailability getItemAvailabilityByItemId(String itemId, String tenantId) {
            return itemAvailabilityRepository.findItemAvailabilityByItemId(itemId);
    }


    public AvailabilityAssemblyBOM getEnrichedAssemblyBomWithAvailability(String tenantId, String itemId,LocalDateTime availabilityDateAndTime) {
        if(availabilityDateAndTime!=null){
            AssemblyBom bom = assemblyBomData(itemId);
            try {
                TenantContext.setTenantId(tenantId);
                if (bom == null || bom.getChildItems() == null) {
                    return null;
                }

                List<String> itemCodes = bom.getChildItems().stream()
                        .map(child -> child.getItemCode())
                        .toList();

                List<ItemAvailability> availabilityList = itemAvailabilityHistoricRepository.findByItemIdInByDate(itemCodes,availabilityDateAndTime);

                Map<String, ItemAvailability> availabilityMap = availabilityList.stream()
                        .collect(Collectors.toMap(ItemAvailability::getItemId, a -> a));

                List<AvailabilityChildItem> enrichedChildren = bom.getChildItems().stream().map(child -> {
                    AvailabilityChildItem enriched = new AvailabilityChildItem();
                    enriched.setChildItemId(child.getChildItemId());
                    enriched.setItemCode(child.getItemCode());
                    enriched.setItemDescription(child.getItemDescription());
                    enriched.setUnitOfMeasureCode(child.getUnitOfMeasureCode());
                    enriched.setQuantityPer(child.getQuantityPer());

                    ItemAvailability availability = availabilityMap.get(child.getItemCode());
                    if (availability != null) {
                        // Use quantity as availability (current stock)
                        enriched.setAvailability(availability.getQuantity());
                    }

                    return enriched;
                }).toList();

                AvailabilityAssemblyBOM response = new AvailabilityAssemblyBOM();
                response.setParentItemId(bom.getParentItemId());
                response.setParentDescription(bom.getParentDescription());
                response.setDivisionCode(bom.getDivisionCode());
                response.setBaseUnitOfMeasure(bom.getBaseUnitOfMeasure());
                response.setPresentCustomBOM(bom.isPresentCustomBOM());
                response.setChildItems(enrichedChildren);

                return response;
            } finally {
                TenantContext.clear();
            }
        }
        else {
            AssemblyBom bom = assemblyBomData(itemId);
            try {
                TenantContext.setTenantId(tenantId);
                if (bom == null || bom.getChildItems() == null) {
                    return null;
                }

                List<String> itemCodes = bom.getChildItems().stream()
                        .map(child -> child.getItemCode())
                        .toList();

                List<ItemAvailability> availabilityList = itemAvailabilityRepository.findByItemIdIn(itemCodes);

                Map<String, ItemAvailability> availabilityMap = availabilityList.stream()
                        .collect(Collectors.toMap(ItemAvailability::getItemId, a -> a));

                List<AvailabilityChildItem> enrichedChildren = bom.getChildItems().stream().map(child -> {
                    AvailabilityChildItem enriched = new AvailabilityChildItem();
                    enriched.setChildItemId(child.getChildItemId());
                    enriched.setItemCode(child.getItemCode());
                    enriched.setItemDescription(child.getItemDescription());
                    enriched.setUnitOfMeasureCode(child.getUnitOfMeasureCode());
                    enriched.setQuantityPer(child.getQuantityPer());

                    ItemAvailability availability = availabilityMap.get(child.getItemCode());
                    if (availability != null) {
                        // Use quantity as availability (current stock)
                        enriched.setAvailability(availability.getQuantity());
                    }

                    return enriched;
                }).toList();

                AvailabilityAssemblyBOM response = new AvailabilityAssemblyBOM();
                response.setParentItemId(bom.getParentItemId());
                response.setParentDescription(bom.getParentDescription());
                response.setDivisionCode(bom.getDivisionCode());
                response.setBaseUnitOfMeasure(bom.getBaseUnitOfMeasure());
                response.setPresentCustomBOM(bom.isPresentCustomBOM());
                response.setChildItems(enrichedChildren);

                return response;
            } finally {
                TenantContext.clear();
            }
        }
    }

    //Custom Bom data on ui
    public AvailabilityAssemblyBOM getEnrichedCustomBomWithAvailability(String tenantId, String itemId,LocalDateTime availabilityDateAndTime) {
        if(availabilityDateAndTime!=null){
            CustomBomGroup bom = getCustomBomData(tenantId,itemId);
            try {
                TenantContext.setTenantId(tenantId);
                if (bom == null || bom.getChildItems() == null) {
                    return null;
                }

                List<String> itemCodes = bom.getChildItems().stream()
                        .map(child -> child.getItemCode())
                        .toList();

                List<ItemAvailability> availabilityList = itemAvailabilityHistoricRepository.findByItemIdInByDate(itemCodes,availabilityDateAndTime);

                Map<String, ItemAvailability> availabilityMap = availabilityList.stream()
                        .collect(Collectors.toMap(ItemAvailability::getItemId, a -> a));

                List<AvailabilityChildItem> enrichedChildren = bom.getChildItems().stream().map(child -> {
                    AvailabilityChildItem enriched = new AvailabilityChildItem();
                    enriched.setChildItemId(child.getChildItemId());
                    enriched.setItemCode(child.getItemCode());
                    enriched.setItemDescription(child.getItemDescription());
                    enriched.setUnitOfMeasureCode(child.getUnitOfMeasureCode());
                    enriched.setQuantityPer(child.getQuantityPer());

                    ItemAvailability availability = availabilityMap.get(child.getItemCode());
                    if (availability != null) {
                        // Use quantity as availability (current stock)
                        enriched.setAvailability(availability.getQuantity());
                    }

                    return enriched;
                }).toList();

                AvailabilityAssemblyBOM response = new AvailabilityAssemblyBOM();
                response.setParentItemId(bom.getCustomBomCode());
                response.setCustomBomGroupCode(bom.getCustomBomGroupCode());
                response.setPresentCustomBOM(true);
                response.setChildItems(enrichedChildren);

                return response;
            } finally {
                TenantContext.clear();
            }
        }
        else {
            CustomBomGroup bom = getCustomBomData(tenantId, itemId);
            try {
                TenantContext.setTenantId(tenantId);
                if (bom == null || bom.getChildItems() == null) {
                    return null;
                }

                List<String> itemCodes = bom.getChildItems().stream()
                        .map(child -> child.getItemCode())
                        .toList();

                List<ItemAvailability> availabilityList = itemAvailabilityRepository.findByItemIdIn(itemCodes);

                Map<String, ItemAvailability> availabilityMap = availabilityList.stream()
                        .collect(Collectors.toMap(ItemAvailability::getItemId, a -> a));

                List<AvailabilityChildItem> enrichedChildren = bom.getChildItems().stream().map(child -> {
                    AvailabilityChildItem enriched = new AvailabilityChildItem();
                    enriched.setChildItemId(child.getChildItemId());
                    enriched.setItemCode(child.getItemCode());
                    enriched.setItemDescription(child.getItemDescription());
                    enriched.setUnitOfMeasureCode(child.getUnitOfMeasureCode());
                    enriched.setQuantityPer(child.getQuantityPer());

                    ItemAvailability availability = availabilityMap.get(child.getItemCode());
                    if (availability != null) {
                        // Use quantity as availability (current stock)
                        enriched.setAvailability(availability.getQuantity());
                    }

                    return enriched;
                }).toList();
                AvailabilityAssemblyBOM response = new AvailabilityAssemblyBOM();
                response.setParentItemId(bom.getCustomBomCode());
                response.setCustomBomGroupCode(bom.getCustomBomGroupCode());
                response.setPresentCustomBOM(true);
                response.setChildItems(enrichedChildren);
                return response;
            } finally {
                TenantContext.clear();
            }
        }
    }

}
