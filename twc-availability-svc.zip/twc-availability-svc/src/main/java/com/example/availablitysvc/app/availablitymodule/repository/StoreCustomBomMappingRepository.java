package com.example.availablitysvc.app.availablitymodule.repository;

import com.example.availablitysvc.app.availablitymodule.entity.StoreCustomBomMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreCustomBomMappingRepository extends JpaRepository<StoreCustomBomMapping, String> {
    StoreCustomBomMapping findByLocationCode(String locationCode);
}
