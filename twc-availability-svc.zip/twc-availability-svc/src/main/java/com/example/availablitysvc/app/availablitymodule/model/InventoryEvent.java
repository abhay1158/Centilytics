package com.example.availablitysvc.app.availablitymodule.model;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record InventoryEvent(String itemCode,
                             String itemDescription,
                             BigDecimal quantity,
                             String unitOfMeasureCode,
                             EventType eventType,
                             LocalDateTime eventLoggedTime,
                             EventNature eventNature,
                             String categoryCode,
                             String inventoryPostingGroup,
                             String tenantId) {}