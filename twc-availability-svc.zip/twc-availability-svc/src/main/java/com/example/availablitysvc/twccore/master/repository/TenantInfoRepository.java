package com.example.availablitysvc.twccore.master.repository;

import com.example.availablitysvc.twccore.master.entity.TenantInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantInfoRepository extends JpaRepository<TenantInfo, String> { }
