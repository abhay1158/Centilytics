package com.example.availablitysvc.app.eventloggingmodule.controller;

import com.example.availablitysvc.app.availablitymodule.service.AvailabilityService;
import com.example.availablitysvc.app.availablitymodule.service.WebClientCallBomService;
import com.example.availablitysvc.app.eventloggingmodule.dto.EventLoggingDto;
import com.example.availablitysvc.app.eventloggingmodule.dto.Filter;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingFilterRequest;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingFilterRequestWithDate;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingModel;
import com.example.availablitysvc.app.eventloggingmodule.model.WrapperResponse;
import com.example.availablitysvc.app.eventloggingmodule.service.EventLoggingService;
import com.example.availablitysvc.app.eventloggingmodule.service.StableIds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class EventLoggingControllerImpl implements EventLoggingController{

    @Autowired
    private EventLoggingService eventLoggingService;

    @Override
    public ResponseEntity<WrapperResponse> eventLogging(EventLoggingModel eventLoggingModel, String tenantId) {
        WrapperResponse response = new WrapperResponse();
        try {
            ResponseEntity<WrapperResponse> message = eventLoggingService.logEvent(eventLoggingModel,tenantId);
            response.setMessage(message.getBody().getMessage());
        } catch (Exception e) {
            response.setMessage("Event logged Failed due to - "+e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    @Override
    public Page<EventLoggingDto> getEventLoggingDataWithFilters(
            @RequestBody EventLoggingFilterRequest req,
            @RequestHeader("X-Tenant-ID") String tenantId) {

        if (req == null) req = new EventLoggingFilterRequest();
        int page = (req.getPage() == null || req.getPage() < 0) ? 0 : req.getPage();
        int size = (req.getSize() == null || req.getSize() <= 0 || req.getSize() > 200) ? 10 : req.getSize();
        req.setSort("eventLoggedTime,desc");
        Sort sort = Sort.by("eventLoggedTime").descending();
        if (req.getSort() != null && !req.getSort().isBlank()) {
            String[] parts = req.getSort().split(",", 2);
            String prop = parts[0].trim();
            boolean desc = parts.length > 1 && "desc".equalsIgnoreCase(parts[1].trim());
            sort = desc ? Sort.by(prop).descending() : Sort.by(prop).ascending();
        }

        Pageable pageable = PageRequest.of(page, size, sort);
        return eventLoggingService.getEventLoggingDataWithFilters(req.getSearchText(),req.getStatus(),
                req.getEventTypes(), tenantId, pageable);
    }

    public Page<EventLoggingDto> getHistoricData(
            @RequestBody EventLoggingFilterRequestWithDate req,
            @RequestHeader("X-Tenant-ID") String tenantId) {

        if (req == null) req = new EventLoggingFilterRequestWithDate();

        int page = (req.getPage() == null || req.getPage() < 0) ? 0 : req.getPage();
        int size = (req.getSize() == null || req.getSize() <= 0 || req.getSize() > 200) ? 10 : req.getSize();
        req.setSort("eventLoggedTime,desc");
        Sort sort = Sort.by("eventLoggedTime").descending();
        if (req.getSort() != null && !req.getSort().isBlank()) {
            String[] parts = req.getSort().split(",", 2);
            String prop = parts[0].trim();
            boolean desc = parts.length > 1 && "desc".equalsIgnoreCase(parts[1].trim());
            sort = desc ? Sort.by(prop).descending() : Sort.by(prop).ascending();
        }

        Pageable pageable = PageRequest.of(page, size, sort);

        return eventLoggingService.getHistoricDataWithFilters(
                req.getSearchText(),
                req.getStatus(),
                req.getEventTypes(),
                req.getFrom(),
                req.getTo(),
                tenantId,
                pageable
        );
    }

    public Filter.FiltersResponse getFilters() {
        List<Filter.FilterOption> status = Arrays.stream(Status.values())
                .map(s -> new Filter.FilterOption(
                        StableIds.uuidFor("status", s.name()),
                        s.name(),
                        StableIds.toLabel(s.name())
                ))
                .toList();

        List<Filter.FilterOption> eventType = Arrays.stream(EventType.values())
                .map(t -> new Filter.FilterOption(
                        StableIds.uuidFor("eventType", t.name()),
                        t.name(),
                        StableIds.toLabel(t.name())
                ))
                .toList();

        return new Filter.FiltersResponse(status, eventType);
    }
}
