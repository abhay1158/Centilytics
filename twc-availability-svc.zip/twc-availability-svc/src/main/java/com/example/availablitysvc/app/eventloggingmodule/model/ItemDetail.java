package com.example.availablitysvc.app.eventloggingmodule.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ItemDetail {
    @NotBlank(message = "itemCode is required")
    private String itemCode;
    private String itemDescription;
    @NotBlank(message = "unitOfMeasure is required")
    private String unitOfMeasure;

    private BigDecimal quantity;

    private String categoryCode;

    @NotNull
    private String inventoryPostingGroup;
}
