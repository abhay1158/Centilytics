package com.example.availablitysvc.app.eventloggingmodule.model;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventNature;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventAvailabilityWrapper {
    @NotNull(message = "eventType is required")
    private EventType eventType;

    @NotBlank(message = "itemCode is required")
    private String itemCode;

    private String itemDescription;

    @NotBlank(message = "unitOfMeasure is required")
    private String unitOfMeasure;

    private BigDecimal quantity;

    private String categoryCode;

    @NotNull
    private String inventoryPostingGroup;

    @NotNull(message = "eventLoggedTime is required")
    private LocalDateTime eventLoggedTime;

    private String reason;
    @NotNull
    private EventNature eventNature;
}
