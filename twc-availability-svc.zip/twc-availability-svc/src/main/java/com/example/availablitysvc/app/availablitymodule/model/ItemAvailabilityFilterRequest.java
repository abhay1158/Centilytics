package com.example.availablitysvc.app.availablitymodule.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ItemAvailabilityFilterRequest {
    private List<String> inventoryGroups;
    private List<String> categoryCodes;
}
