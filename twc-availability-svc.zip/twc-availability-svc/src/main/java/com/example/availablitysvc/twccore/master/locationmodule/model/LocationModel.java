package com.example.availablitysvc.twccore.master.locationmodule.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "locations_availability")
@Data
public class LocationModel {

    @Id
    private String code;

    private String name;
    private String address;
    private String address_2;
    private String city;
    private String country;

    @Column(name = "enable_location")
    private boolean enableLocation;
}