package com.example.availablitysvc.app.eventloggingmodule.model;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EventLoggingFilterRequest {
    private List<Status> status;
    private List<EventType> eventTypes;
    private String searchText;
    private Integer page;
    private Integer size;
    private String sort;
}
