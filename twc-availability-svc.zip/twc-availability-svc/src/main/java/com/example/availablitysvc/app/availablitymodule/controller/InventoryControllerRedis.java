package com.example.availablitysvc.app.availablitymodule.controller;

// InventoryController.java
import java.time.Duration;
import java.util.List;

import com.example.availablitysvc.app.availablitymodule.model.InventoryEvent;
import com.example.availablitysvc.app.availablitymodule.model.InventoryMessage;
import com.example.availablitysvc.app.availablitymodule.service.InventoryStreamPoller;
import com.example.availablitysvc.app.availablitymodule.service.InventoryStreamProducer;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
public class InventoryControllerRedis {

    private final InventoryStreamProducer producer;
    private final InventoryStreamPoller poller;

    public InventoryControllerRedis(InventoryStreamProducer producer, InventoryStreamPoller poller) {
        this.producer = producer;
        this.poller = poller;
    }

    // Produce
    @PostMapping("/enqueue")
    public ResponseEntity<String> enqueue(@RequestBody InventoryEvent e) {
        var id = producer.enqueue(e);
        return ResponseEntity.ok(id.getValue());
    }

    // Poll (blocks up to blockMs)
    @GetMapping("/poll")
    public ResponseEntity<List<InventoryMessage>> poll(
            @RequestParam(defaultValue = "5000") long blockMs,
            @RequestParam(defaultValue = "10") int count) {
        var msgs = poller.pollOnce(Duration.ofMillis(blockMs), count);
        return ResponseEntity.ok(msgs);
    }

    // Ack one
    @PostMapping("/ack/{id}")
    public ResponseEntity<Void> ack(@PathVariable String id) {
        poller.ack(id);
        return ResponseEntity.noContent().build();
    }

    // Ack many
    @PostMapping("/ack")
    public ResponseEntity<Void> ackMany(@RequestBody List<String> ids) {
        poller.ackAll(ids);
        return ResponseEntity.noContent().build();
    }
}

