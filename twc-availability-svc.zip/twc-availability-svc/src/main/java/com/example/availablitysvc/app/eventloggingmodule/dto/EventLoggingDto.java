package com.example.availablitysvc.app.eventloggingmodule.dto;

import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventLoggingDto {
    private Long eventId;
    private EventType eventType;
    private LocalDateTime eventLoggedTime;
    private Status status;
    private String reason;
    private BigDecimal quantity;
    private String unitOfMeasure;
    private String itemCode;
    private String itemDescription;
}
