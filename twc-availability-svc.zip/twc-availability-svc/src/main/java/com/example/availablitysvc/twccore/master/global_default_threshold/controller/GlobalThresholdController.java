package com.example.availablitysvc.twccore.master.global_default_threshold.controller;

import com.example.availablitysvc.twccore.master.global_default_threshold.dto.GlobalThresholdDto;
import com.example.availablitysvc.twccore.master.global_default_threshold.service.GlobalThresholdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/global-threshold")
public class GlobalThresholdController {

    @Autowired
    private GlobalThresholdService globalThresholdService;
    @GetMapping
    public List<GlobalThresholdDto> getGlobalThreshold() {
        return globalThresholdService.getGlobalThreshold();
    }
}
