package com.example.availablitysvc.app.eventloggingmodule.service;

import com.example.availablitysvc.app.eventloggingmodule.dto.EventLoggingDto;
import com.example.availablitysvc.app.eventloggingmodule.enums.EventType;
import com.example.availablitysvc.app.eventloggingmodule.enums.Status;
import com.example.availablitysvc.app.eventloggingmodule.model.EventAvailabilityWrapper;
import com.example.availablitysvc.app.eventloggingmodule.model.EventLoggingModel;
import com.example.availablitysvc.app.eventloggingmodule.model.WrapperResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.List;


public interface EventLoggingService {
    ResponseEntity<WrapperResponse> logEvent(EventLoggingModel eventLoggingModel, String tenantId);
    ResponseEntity<WrapperResponse> failedLogEvent(EventAvailabilityWrapper eventAvailabilityWrapper, String tenantId);

    Page<EventLoggingDto> getEventLoggingDataWithFilters(String searchText, List<Status> statuses,
                                                         List<EventType> eventTypes, String tenantId,
                                                         Pageable pageable
    );

    Page<EventLoggingDto> getHistoricDataWithFilters(
            String searchText,
            List<Status> statuses,
            List<EventType> eventTypes,
            LocalDateTime from,
            LocalDateTime to,
            String tenantId,
            Pageable pageable
    );


}
