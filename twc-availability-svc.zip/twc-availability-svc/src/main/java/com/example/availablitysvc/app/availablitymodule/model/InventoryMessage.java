package com.example.availablitysvc.app.availablitymodule.model;

public record InventoryMessage(String id, InventoryEvent event) {}
