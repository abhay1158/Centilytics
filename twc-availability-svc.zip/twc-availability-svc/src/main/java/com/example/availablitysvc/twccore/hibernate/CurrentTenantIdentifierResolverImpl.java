package com.example.availablitysvc.twccore.hibernate;

import com.example.availablitysvc.twccore.tenant.TenantContext;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CurrentTenantIdentifierResolverImpl implements CurrentTenantIdentifierResolver {

    private final String defaultTenant;

    public CurrentTenantIdentifierResolverImpl(@Value("${eventloggingmodule.default-tenant:default}") String defaultTenant) {
        this.defaultTenant = defaultTenant;
    }

    @Override
    public String resolveCurrentTenantIdentifier() {
        String t = TenantContext.getTenantId();
        return (t == null || t.isBlank()) ? defaultTenant : t;
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }
}
