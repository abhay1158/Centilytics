package com.example.availablitysvc.app.availablitymodule.service;

import com.example.availablitysvc.app.availablitymodule.model.AssemblyBom;
import com.example.availablitysvc.app.availablitymodule.model.CustomBomGroup;
import com.example.availablitysvc.app.availablitymodule.model.PageResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;


@Service
public class WebClientCallBomService {

    private final WebClient webClient;
    private final ObjectMapper mapper = new ObjectMapper();

    public WebClientCallBomService(WebClient.Builder builder) {
        this.webClient = builder.baseUrl("https://centra-api.thirdwavecoffee.in").build();
    }

    private static final String JWT_REGEX = "^[A-Za-z0-9\\-_=]+\\.[A-Za-z0-9\\-_=]+\\.[A-Za-z0-9\\-_=]+$";

    public String loginAndGetToken(String username, String password) {
        String body = webClient.post()
                .uri("/login")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(Map.of("userName", username, "password", password))
                .retrieve()
                .onStatus(s -> s.isError(), resp ->
                        resp.bodyToMono(String.class).defaultIfEmpty("")
                                .flatMap(b -> Mono.error(new IllegalStateException("Login failed: " + resp.statusCode() + " body: " + b))))
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30))
                .block();

        if (body == null || body.isBlank()) {
            throw new IllegalStateException("Empty login response");
        }

        String trimmed = body.trim().replace("\"", "");
        if (trimmed.matches(JWT_REGEX)) {
            return trimmed;
        }

        try {
            JsonNode json = mapper.readTree(body);
            String token = extractToken(json);
            if (token != null && token.matches(JWT_REGEX)) {
                return token;
            }
        } catch (Exception ignore) {
            // fall-through to error
        }

        throw new IllegalStateException("Could not extract JWT from login response: " + body);
    }

    private static String extractToken(JsonNode json) {
        if (json == null) return null;
        if (json.hasNonNull("token")) return json.get("token").asText();
        if (json.hasNonNull("jwtToken")) return json.get("jwtToken").asText();
        if (json.hasNonNull("accessToken")) return json.get("accessToken").asText();

        JsonNode data = json.get("data");
        if (data != null) {
            if (data.hasNonNull("token")) return data.get("token").asText();
            if (data.hasNonNull("jwtToken")) return data.get("jwtToken").asText();
            if (data.hasNonNull("accessToken")) return data.get("accessToken").asText();
        }
        JsonNode result = json.get("result");
        if (result != null) {
            if (result.hasNonNull("token")) return result.get("token").asText();
            if (result.hasNonNull("jwtToken")) return result.get("jwtToken").asText();
            if (result.hasNonNull("accessToken")) return result.get("accessToken").asText();
        }
        return null;
    }

    public AssemblyBom getAssemblyBom(String parentItemCode) {
        String token = loginAndGetToken("admin", "vN0q4IDL3TYsWRx");

        PageResponse<AssemblyBom> page = webClient.get()
                .uri(uri -> uri.path("/bom/assembly")
                        .queryParam("parentItemCode", parentItemCode)
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .retrieve()
                .onStatus(s -> s.isError(), resp -> resp.bodyToMono(String.class)
                        .defaultIfEmpty("")
                        .flatMap(b -> Mono.error(new IllegalStateException(
                                "GET /bom/assembly failed: " + resp.statusCode() + " body: " + b))))
                .bodyToMono(new ParameterizedTypeReference<PageResponse<AssemblyBom>>() {})
                .timeout(Duration.ofSeconds(30))
                .block();

        if (page == null || page.getContent() == null || page.getContent().isEmpty()) {
            throw new IllegalStateException("No AssemblyBom found for code " + parentItemCode);
        }
        return page.getContent().get(0);
    }

    public List<CustomBomGroup> getCustomBom(String parentItemCode) {
        String token = loginAndGetToken("admin", "vN0q4IDL3TYsWRx");
        List<CustomBomGroup> customBomGroups = webClient.get()
                .uri(uri -> uri.path("/bom/custom-bom")
                        .queryParam("parentItemId", parentItemCode)
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .retrieve()
                .onStatus(s -> s.isError(), resp -> resp.bodyToMono(String.class)
                        .defaultIfEmpty("")
                        .flatMap(b -> Mono.error(new IllegalStateException(
                                "GET /bom/custom-bom failed: " + resp.statusCode() + " body: " + b))))
                .bodyToMono(new ParameterizedTypeReference<List<CustomBomGroup>>() {})
                .timeout(Duration.ofSeconds(30))
                .block();

        return customBomGroups;
    }

}